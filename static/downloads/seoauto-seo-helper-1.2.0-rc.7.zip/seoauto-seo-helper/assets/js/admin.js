(function () {
  'use strict';

  // Pairing code sanitize (Connect page).
  var input = document.getElementById('pairing_code');
  if (input) {
    input.addEventListener('input', function () {
      input.value = String(input.value || '')
        .toUpperCase()
        .replace(/[^A-Z0-9-]/g, '');
    });
  }

  // SEO Audit live progress panel.
  var panel = document.getElementById('seoauto-audit-panel');
  if (!panel || panel.getAttribute('data-poll') !== '1') {
    return;
  }

  var cfg = window.seoautoHelperAudit || {};
  var ajaxUrl = cfg.ajaxUrl || panel.getAttribute('data-ajax') || '';
  var nonce = cfg.nonce || panel.getAttribute('data-nonce') || '';
  var i18n = cfg.i18n || {};
  var POLL_MS = 7000;
  var busy = false;
  var timer = null;

  function el(id) {
    return document.getElementById(id);
  }

  function sprintf(template) {
    var args = Array.prototype.slice.call(arguments, 1);
    var i = 0;
    return String(template || '').replace(/%(\d+)\$[sd]|%s|%d/g, function (m, n) {
      if (n) {
        return String(args[parseInt(n, 10) - 1] != null ? args[parseInt(n, 10) - 1] : '');
      }
      var v = args[i++];
      return String(v != null ? v : '');
    });
  }

  function applySnapshot(data) {
    if (!data) return;
    var progress = el('seoauto-audit-progress');
    var active = !!data.active;
    if (progress) {
      progress.style.display = active || (data.processed > 0 && data.percent < 100) ? '' : progress.style.display;
      if (active) {
        progress.style.display = '';
      }
      if (!active && data.percent >= 100) {
        // Keep panel visible briefly with completed stats.
        progress.style.display = '';
      }
      if (!active && !data.job) {
        progress.style.display = 'none';
      }
    }

    var fill = el('seoauto-audit-bar-fill');
    if (fill) {
      fill.style.width = String(data.percent || 0) + '%';
    }

    var stats = el('seoauto-audit-stats');
    if (stats) {
      stats.textContent = sprintf(
        i18n.progress || 'Tiến độ: %1$d%% — %2$d / %3$d đối tượng — Issues: %4$d',
        data.percent || 0,
        data.processed || 0,
        data.total || 0,
        data.issues || 0
      );
    }

    var hb = el('seoauto-audit-heartbeat');
    if (hb) {
      hb.textContent = sprintf(
        i18n.heartbeat || 'Heartbeat (GMT): %s',
        data.heartbeat_gmt || '—'
      );
    }

    var job = data.job || null;
    var run = data.run || null;
    var jobLine = el('seoauto-audit-job-line');
    if (jobLine && job) {
      jobLine.textContent = sprintf(
        i18n.jobLine || 'Job #%1$d — %2$s | Run #%3$d — %4$s',
        job.id || 0,
        job.status || '',
        job.run_id || 0,
        (run && run.status) || ''
      );
    }

    var staleBox = el('seoauto-audit-stale');
    if (staleBox) {
      staleBox.style.display = data.stale ? '' : 'none';
    }

    var cronEl = el('seoauto-audit-cron');
    if (cronEl && data.cron) {
      var c = data.cron;
      if (c.wp_cron_disabled) {
        cronEl.textContent = 'Cron: DISABLE_WP_CRON — ' + (c.hook || '');
      } else if (!c.scheduled) {
        cronEl.textContent = 'Cron: hook chưa lên lịch';
      } else {
        var next = c.next_ts ? new Date(c.next_ts * 1000).toISOString().substr(11, 8) + ' UTC' : '—';
        cronEl.textContent = 'Cron: ' + (c.hook || '') + ' — ~ ' + next;
      }
    }

    // Sync recent runs table row if present.
    if (run && run.id) {
      var row = document.querySelector('#seoauto-audit-runs-table tr[data-run-id="' + run.id + '"]');
      if (row) {
        var st = row.querySelector('.seoauto-run-status');
        var pr = row.querySelector('.seoauto-run-progress');
        var iss = row.querySelector('.seoauto-run-issues');
        if (st) st.textContent = run.status || '';
        if (pr) pr.textContent = (run.processed || 0) + ' / ' + (run.total || 0);
        if (iss) iss.textContent = String(run.issues || 0);
      }
    }

    // Hide start form while active.
    var form = el('seoauto-audit-start-form');
    if (form) {
      form.style.display = active ? 'none' : '';
    }
  }

  function post(action) {
    var body = new FormData();
    body.append('action', action);
    body.append('nonce', nonce);
    return fetch(ajaxUrl, {
      method: 'POST',
      credentials: 'same-origin',
      body: body
    }).then(function (res) {
      return res.json();
    });
  }

  function poll() {
    if (busy || !ajaxUrl || !nonce) return;
    busy = true;
    post('seoauto_helper_audit_status')
      .then(function (json) {
        if (json && json.success && json.data) {
          applySnapshot(json.data);
        }
      })
      .catch(function () {
        /* silent — next poll retries */
      })
      .finally(function () {
        busy = false;
      });
  }

  var runNowBtn = el('seoauto-audit-run-now');
  if (runNowBtn) {
    runNowBtn.addEventListener('click', function () {
      if (busy) return;
      busy = true;
      runNowBtn.disabled = true;
      var hint = el('seoauto-audit-poll-hint');
      if (hint) hint.textContent = i18n.running || 'Đang chạy batch…';
      post('seoauto_helper_audit_run_now')
        .then(function (json) {
          if (json && json.success && json.data) {
            applySnapshot(json.data);
            if (hint && !json.data.active) {
              hint.textContent = i18n.done || 'Quét đã hoàn thành.';
            } else if (hint) {
              hint.textContent = 'Tự cập nhật mỗi 7 giây.';
            }
          } else if (hint) {
            hint.textContent = i18n.error || 'Không cập nhật được tiến độ. Thử lại.';
          }
        })
        .catch(function () {
          if (hint) hint.textContent = i18n.error || 'Không cập nhật được tiến độ. Thử lại.';
        })
        .finally(function () {
          busy = false;
          runNowBtn.disabled = false;
        });
    });
  }

  // Initial + interval poll.
  poll();
  timer = window.setInterval(poll, POLL_MS);
  window.addEventListener('beforeunload', function () {
    if (timer) window.clearInterval(timer);
  });
})();
