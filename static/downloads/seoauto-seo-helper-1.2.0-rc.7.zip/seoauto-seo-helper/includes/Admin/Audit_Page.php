<?php
/**
 * Admin — SEO Audit runs & issues (Phase 1 scan-only).
 *
 * @package SEOAuto\SEOHelper
 */

declare(strict_types=1);

namespace SEOAuto\SEOHelper\Admin;

use SEOAuto\SEOHelper\Entitlement\Entitlement_Manager;
use SEOAuto\SEOHelper\SeoAudit\Audit_Job_Runner;
use SEOAuto\SEOHelper\SeoAudit\Issue_Presenter;
use SEOAuto\SEOHelper\SeoAudit\Job_Store;
use SEOAuto\SEOHelper\SeoAudit\Object_Context;
use WP_Error;

final class Audit_Page {

	public function __construct(
		private Audit_Job_Runner $runner,
		private Entitlement_Manager $entitlement
	) {}

	public function render(): void {
		Admin_View::wrap_start(
			__( 'SEO Audit', 'seoauto-seo-helper' ),
			__( 'Quét SEO hàng loạt (WP-Cron). Phase 1: chỉ quét — chưa Auto Fix.', 'seoauto-seo-helper' )
		);
		Admin_View::nav_tabs( 'audit', $this->entitlement );

		$locked = $this->entitlement->is_locked();
		$caps   = $this->entitlement->capabilities();
		Admin_View::render_status_notices(
			$locked,
			(bool) ( $caps['network_grace_active'] ?? false ),
			$caps,
			(string) ( $caps['upgrade_url'] ?? '' )
		);

		$run_id = isset( $_GET['run_id'] ) ? absint( $_GET['run_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( $run_id > 0 ) {
			$this->render_run_detail( $run_id );
		} else {
			$this->render_list();
		}

		Admin_View::wrap_end();
	}

	private function render_list(): void {
		$types    = Object_Context::audit_post_types();
		$snapshot = $this->runner->progress_snapshot();

		echo '<div class="seoauto-helper-card" id="seoauto-audit-panel"';
		echo ' data-poll="1"';
		echo ' data-nonce="' . esc_attr( wp_create_nonce( 'seoauto_helper_audit_ajax' ) ) . '"';
		echo ' data-ajax="' . esc_url( admin_url( 'admin-ajax.php' ) ) . '">';
		echo '<h2>' . esc_html__( 'Bắt đầu quét', 'seoauto-seo-helper' ) . '</h2>';
		echo '<p>' . esc_html(
			sprintf(
				/* translators: %s: post types */
				__( 'Đối tượng: %s. Batch 20 / phút qua WP-Cron.', 'seoauto-seo-helper' ),
				implode( ', ', $types )
			)
		) . '</p>';
		echo '<p><strong>' . esc_html__( 'Checkers:', 'seoauto-seo-helper' ) . '</strong> ';
		echo esc_html( implode( ', ', $this->runner->engine()->checker_ids() ) );
		echo '</p>';

		$this->render_progress_panel( $snapshot );
		$this->render_start_controls( $snapshot );
		echo '</div>';

		$runs = $this->runner->runs()->recent( 15 );
		echo '<div class="seoauto-helper-card">';
		echo '<h2>' . esc_html__( 'Lần quét gần đây', 'seoauto-seo-helper' ) . '</h2>';
		if ( $runs === array() ) {
			echo '<p>' . esc_html__( 'Chưa có lần quét nào.', 'seoauto-seo-helper' ) . '</p>';
		} else {
			echo '<table class="widefat striped" id="seoauto-audit-runs-table"><thead><tr>';
			echo '<th>ID</th><th>' . esc_html__( 'Trạng thái', 'seoauto-seo-helper' ) . '</th>';
			echo '<th>' . esc_html__( 'Tiến độ', 'seoauto-seo-helper' ) . '</th>';
			echo '<th>' . esc_html__( 'Issues', 'seoauto-seo-helper' ) . '</th>';
			echo '<th>' . esc_html__( 'Adapter', 'seoauto-seo-helper' ) . '</th>';
			echo '<th></th></tr></thead><tbody>';
			foreach ( $runs as $run ) {
				$url = admin_url( 'admin.php?page=' . Admin_Menu::SLUG_AUDIT . '&run_id=' . (int) $run['id'] );
				echo '<tr data-run-id="' . (int) $run['id'] . '">';
				echo '<td>' . (int) $run['id'] . '</td>';
				echo '<td class="seoauto-run-status">' . esc_html( (string) $run['status'] ) . '</td>';
				echo '<td class="seoauto-run-progress">' . (int) $run['processed_objects'] . ' / ' . (int) $run['total_objects'] . '</td>';
				echo '<td class="seoauto-run-issues">' . (int) $run['issues_found'] . '</td>';
				echo '<td>' . esc_html( (string) ( $run['seo_adapter'] ?? '' ) ) . '</td>';
				echo '<td><a href="' . esc_url( $url ) . '">' . esc_html__( 'Chi tiết', 'seoauto-seo-helper' ) . '</a></td>';
				echo '</tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';
	}

	/**
	 * @param array<string,mixed> $snapshot
	 */
	private function render_progress_panel( array $snapshot ): void {
		$active  = ! empty( $snapshot['active'] );
		$percent = (int) ( $snapshot['percent'] ?? 0 );
		$proc    = (int) ( $snapshot['processed'] ?? 0 );
		$total   = (int) ( $snapshot['total'] ?? 0 );
		$issues  = (int) ( $snapshot['issues'] ?? 0 );
		$job     = is_array( $snapshot['job'] ?? null ) ? $snapshot['job'] : null;
		$run     = is_array( $snapshot['run'] ?? null ) ? $snapshot['run'] : null;
		$cron    = is_array( $snapshot['cron'] ?? null ) ? $snapshot['cron'] : array();
		$stale   = ! empty( $snapshot['stale'] );
		$hb      = (string) ( $snapshot['heartbeat_gmt'] ?? '' );

		$job_status = $job ? (string) ( $job['status'] ?? '' ) : '';
		$run_status = $run ? (string) ( $run['status'] ?? '' ) : '';

		echo '<div id="seoauto-audit-progress" class="seoauto-audit-progress" style="margin:12px 0;' . ( $active ? '' : 'display:none;' ) . '">';
		echo '<div class="notice notice-info inline" style="margin:0;padding:10px 12px;">';
		echo '<p><strong id="seoauto-audit-active-label">' . esc_html__( 'Đang có job quét SEO', 'seoauto-seo-helper' ) . '</strong></p>';
		echo '<p id="seoauto-audit-job-line">';
		if ( $job ) {
			echo esc_html(
				sprintf(
					/* translators: 1: job id 2: job status 3: run id 4: run status */
					__( 'Job #%1$d — %2$s | Run #%3$d — %4$s', 'seoauto-seo-helper' ),
					(int) $job['id'],
					$job_status,
					(int) ( $job['run_id'] ?? 0 ),
					$run_status
				)
			);
		}
		echo '</p>';

		echo '<div class="seoauto-audit-bar" style="background:#dcdcde;border-radius:4px;height:18px;overflow:hidden;max-width:480px;">';
		echo '<div id="seoauto-audit-bar-fill" style="background:#2271b1;height:100%;width:' . esc_attr( (string) $percent ) . '%;transition:width .3s;"></div>';
		echo '</div>';
		echo '<p id="seoauto-audit-stats" style="margin-top:8px;">';
		echo esc_html(
			sprintf(
				/* translators: 1: percent 2: processed 3: total 4: issues */
				__( 'Tiến độ: %1$d%% — %2$d / %3$d đối tượng — Issues: %4$d', 'seoauto-seo-helper' ),
				$percent,
				$proc,
				$total,
				$issues
			)
		);
		echo '</p>';
		echo '<p id="seoauto-audit-heartbeat" class="description">';
		echo esc_html(
			sprintf(
				/* translators: %s: GMT timestamp */
				__( 'Heartbeat (GMT): %s', 'seoauto-seo-helper' ),
				$hb !== '' ? $hb : '—'
			)
		);
		echo '</p>';
		echo '<p id="seoauto-audit-cron" class="description">';
		echo esc_html( $this->cron_status_text( $cron ) );
		echo '</p>';

		echo '<div id="seoauto-audit-stale" style="' . ( $stale ? '' : 'display:none;' ) . '">';
		echo '<p class="notice notice-warning inline" style="margin:8px 0;padding:8px 12px;">';
		echo esc_html__( 'Cron có vẻ bị treo hoặc chậm — tiến độ không cập nhật. Bấm “Chạy tiếp ngay” để xử lý một batch.', 'seoauto-seo-helper' );
		echo '</p></div>';

		echo '<p style="margin-top:8px;">';
		echo '<button type="button" class="button" id="seoauto-audit-run-now">' . esc_html__( 'Chạy tiếp ngay', 'seoauto-seo-helper' ) . '</button> ';
		echo '<span id="seoauto-audit-poll-hint" class="description">' . esc_html__( 'Tự cập nhật mỗi 7 giây.', 'seoauto-seo-helper' ) . '</span>';
		echo '</p>';
		echo '</div></div>';
	}

	/**
	 * @param array<string,mixed> $cron
	 */
	private function cron_status_text( array $cron ): string {
		$hook = (string) ( $cron['hook'] ?? Audit_Job_Runner::HOOK_PROCESS );
		if ( ! empty( $cron['wp_cron_disabled'] ) ) {
			return sprintf(
				/* translators: %s: cron hook */
				__( 'Cron: DISABLE_WP_CRON bật — cần system cron gọi %s.', 'seoauto-seo-helper' ),
				$hook
			);
		}
		if ( empty( $cron['scheduled'] ) ) {
			return __( 'Cron: hook chưa được lên lịch.', 'seoauto-seo-helper' );
		}
		$next = (int) ( $cron['next_ts'] ?? 0 );
		$when = $next > 0 ? gmdate( 'H:i:s', $next ) . ' UTC' : '—';
		return sprintf(
			/* translators: 1: hook 2: next run time */
			__( 'Cron: %1$s — lần chạy tiếp theo ~ %2$s', 'seoauto-seo-helper' ),
			$hook,
			$when
		);
	}

	/**
	 * @param array<string,mixed> $snapshot
	 */
	private function render_start_controls( array $snapshot ): void {
		$has_feature = $this->entitlement->has_feature( Audit_Job_Runner::FEATURE );
		$gate        = $this->runner->can_start_scan();
		$active      = ! empty( $snapshot['active'] );
		$can_start   = $has_feature && true === $gate && ! $active;

		if ( $active ) {
			echo '<p id="seoauto-audit-start-blocked" class="description">';
			echo esc_html__( 'Không tạo job mới khi đang có job active. Chờ hoàn thành hoặc dùng “Chạy tiếp ngay”.', 'seoauto-seo-helper' );
			echo '</p>';
			return;
		}

		if ( $can_start ) {
			echo '<form method="post" id="seoauto-audit-start-form">';
			wp_nonce_field( 'seoauto_helper_admin' );
			echo '<input type="hidden" name="seoauto_helper_action" value="audit_start_scan" />';
			submit_button( __( 'Bắt đầu quét SEO', 'seoauto-seo-helper' ), 'primary', 'submit', false );
			echo '</form>';
			return;
		}

		$reason = $this->deny_reason( $has_feature, $gate );
		echo '<div class="notice notice-warning inline" style="margin:12px 0;padding:8px 12px;">';
		echo '<p><strong>' . esc_html__( 'Không thể bắt đầu quét SEO.', 'seoauto-seo-helper' ) . '</strong></p>';
		echo '<p>' . esc_html( $reason ) . '</p>';
		echo '</div>';
		echo '<p>';
		submit_button(
			__( 'Bắt đầu quét SEO', 'seoauto-seo-helper' ),
			'primary',
			'submit',
			false,
			array(
				'disabled' => 'disabled',
				'id'       => 'seoauto-audit-start-disabled',
			)
		);
		echo '</p>';
	}

	/**
	 * @param bool|WP_Error $gate
	 */
	private function deny_reason( bool $has_feature, bool|WP_Error $gate ): string {
		if ( ! $has_feature ) {
			return __(
				'Gói hiện tại chưa được cấp quyền seo_audit. Nâng cấp gói hoặc liên hệ SEOAuto để kích hoạt SEO Audit (mã: seoauto_feature_denied).',
				'seoauto-seo-helper'
			);
		}
		if ( $gate instanceof WP_Error ) {
			$code = $gate->get_error_code();
			$msg  = $gate->get_error_message();
			if ( $code !== '' && ! str_contains( $msg, $code ) ) {
				return $msg . ' (' . $code . ')';
			}
			return $msg;
		}
		return __( 'Không thể bắt đầu quét lúc này.', 'seoauto-seo-helper' );
	}

	private function render_run_detail( int $run_id ): void {
		$run = $this->runner->runs()->get( $run_id );
		if ( null === $run ) {
			echo '<p>' . esc_html__( 'Run không tồn tại.', 'seoauto-seo-helper' ) . '</p>';
			return;
		}

		echo '<p><a href="' . esc_url( admin_url( 'admin.php?page=' . Admin_Menu::SLUG_AUDIT ) ) . '">&larr; ';
		echo esc_html__( 'Tất cả lần quét', 'seoauto-seo-helper' ) . '</a></p>';

		echo '<div class="seoauto-helper-card">';
		echo '<h2>' . esc_html( sprintf( /* translators: %d: run id */ __( 'Run #%d', 'seoauto-seo-helper' ), $run_id ) ) . '</h2>';
		echo '<ul>';
		echo '<li><strong>status:</strong> ' . esc_html( (string) $run['status'] ) . '</li>';
		echo '<li><strong>progress:</strong> ' . (int) $run['processed_objects'] . ' / ' . (int) $run['total_objects'] . '</li>';
		echo '<li><strong>cursor:</strong> ' . (int) $run['cursor_id'] . '</li>';
		echo '<li><strong>issues:</strong> ' . (int) $run['issues_found'] . '</li>';
		echo '<li><strong>adapter:</strong> ' . esc_html( (string) ( $run['seo_adapter'] ?? '' ) ) . '</li>';
		echo '<li><strong>request_id:</strong> <code>' . esc_html( (string) $run['request_id'] ) . '</code></li>';
		echo '</ul>';
		echo '</div>';

		$issues = $this->runner->issues()->query(
			array(
				'run_id' => $run_id,
				'limit'  => 100,
			)
		);
		echo '<div class="seoauto-helper-card">';
		echo '<h2>' . esc_html__( 'Issues', 'seoauto-seo-helper' ) . '</h2>';
		if ( $issues === array() ) {
			echo '<p>' . esc_html__( 'Chưa có issue (hoặc scan chưa chạy xong).', 'seoauto-seo-helper' ) . '</p>';
		} else {
			echo '<table class="widefat striped"><thead><tr>';
			echo '<th>' . esc_html__( 'Mức độ', 'seoauto-seo-helper' ) . '</th>';
			echo '<th>' . esc_html__( 'Mã', 'seoauto-seo-helper' ) . '</th>';
			echo '<th>' . esc_html__( 'Nội dung', 'seoauto-seo-helper' ) . '</th>';
			echo '<th>' . esc_html__( 'Hiện tại', 'seoauto-seo-helper' ) . '</th>';
			echo '<th>' . esc_html__( 'Gợi ý', 'seoauto-seo-helper' ) . '</th>';
			echo '<th>' . esc_html__( 'Rủi ro', 'seoauto-seo-helper' ) . '</th>';
			echo '<th>' . esc_html__( 'Trạng thái', 'seoauto-seo-helper' ) . '</th>';
			echo '<th>' . esc_html__( 'Thao tác', 'seoauto-seo-helper' ) . '</th>';
			echo '</tr></thead><tbody>';
			foreach ( $issues as $issue ) {
				$row = Issue_Presenter::present( $issue );
				echo '<tr>';
				echo '<td>' . esc_html( $row['severity'] ) . '</td>';
				echo '<td><code>' . esc_html( $row['code'] ) . '</code></td>';
				echo '<td>';
				echo '<strong>' . esc_html( $row['title'] ) . '</strong><br />';
				echo '<span class="description">' . esc_html( $row['type_label'] . ' #' . $row['object_id'] ) . '</span>';
				if ( $row['url'] !== '' ) {
					echo '<br /><a href="' . esc_url( $row['url'] ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( mb_substr( $row['url'], 0, 60 ) ) . '</a>';
				}
				echo '</td>';
				echo '<td>' . esc_html( mb_substr( $row['current'], 0, 120 ) ) . '</td>';
				echo '<td>' . esc_html( mb_substr( $row['suggested'], 0, 120 ) ) . '</td>';
				echo '<td>' . esc_html( $row['risk'] ) . '</td>';
				echo '<td>' . esc_html( $row['status'] ) . '</td>';
				echo '<td style="white-space:nowrap;">';
				if ( $row['view_url'] !== '' ) {
					echo '<a class="button button-small" href="' . esc_url( $row['view_url'] ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Xem', 'seoauto-seo-helper' ) . '</a> ';
				}
				if ( $row['edit_url'] !== '' ) {
					echo '<a class="button button-small" href="' . esc_url( $row['edit_url'] ) . '">' . esc_html__( 'Chỉnh sửa', 'seoauto-seo-helper' ) . '</a>';
				}
				echo '</td>';
				echo '</tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';
	}
}
