<?php
/**
 * One-time nonce store (replay protection).
 *
 * Atomic claim via add_option (unique option_name) so concurrent PHP-FPM
 * workers cannot both accept the same nonce.
 *
 * @package SEOAuto\SEOHelper
 */

declare(strict_types=1);

namespace SEOAuto\SEOHelper\Auth;

final class Nonce_Store {

	private const TTL = 600; // 10 minutes > skew window
	private const MAX = 500;

	private function index_key(): string {
		return SEOAUTO_HELPER_PREFIX . 'used_nonces';
	}

	private function row_key( string $nonce ): string {
		return SEOAUTO_HELPER_PREFIX . 'n_' . hash( 'sha256', $nonce );
	}

	/**
	 * Returns true if nonce is fresh and was recorded; false if already used.
	 */
	public function claim( string $nonce ): bool {
		$nonce = trim( $nonce );
		if ( $nonce === '' || strlen( $nonce ) > 128 ) {
			return false;
		}

		$now     = time();
		$row_key = $this->row_key( $nonce );
		$expiry  = $now + self::TTL;

		$existing = get_option( $row_key, null );
		if ( null !== $existing && false !== $existing ) {
			$exp = (int) $existing;
			if ( $exp >= $now ) {
				return false;
			}
			delete_option( $row_key );
		}

		// add_option is atomic on unique option_name — second worker gets false.
		$added = add_option( $row_key, $expiry, '', false );
		if ( ! $added ) {
			$again = (int) get_option( $row_key, 0 );
			if ( $again >= $now ) {
				return false;
			}
			// Expired race: replace.
			update_option( $row_key, $expiry, false );
		}

		$this->index_touch( $row_key, $expiry, $now );
		return true;
	}

	/**
	 * Keep a pruned index for cleanup (best-effort; claim itself is atomic).
	 */
	private function index_touch( string $row_key, int $expiry, int $now ): void {
		$rows = $this->load_index();
		$rows = $this->prune_index( $rows, $now );
		$rows[ $row_key ] = $expiry;
		if ( count( $rows ) > self::MAX ) {
			asort( $rows );
			$drop = array_slice( $rows, 0, count( $rows ) - self::MAX, true );
			foreach ( array_keys( $drop ) as $old ) {
				delete_option( (string) $old );
				unset( $rows[ $old ] );
			}
		}
		$this->save_index( $rows );
	}

	/**
	 * @return array<string,int>
	 */
	private function load_index(): array {
		$raw = get_option( $this->index_key(), array() );
		if ( ! is_array( $raw ) ) {
			return array();
		}
		$out = array();
		foreach ( $raw as $k => $v ) {
			$out[ (string) $k ] = (int) $v;
		}
		return $out;
	}

	/**
	 * @param array<string,int> $rows
	 * @return array<string,int>
	 */
	private function prune_index( array $rows, int $now ): array {
		foreach ( $rows as $k => $exp ) {
			if ( (int) $exp < $now ) {
				delete_option( (string) $k );
				unset( $rows[ $k ] );
			}
		}
		return $rows;
	}

	/**
	 * @param array<string,int> $rows
	 */
	private function save_index( array $rows ): void {
		if ( false === get_option( $this->index_key(), false ) && ! $this->index_exists() ) {
			add_option( $this->index_key(), $rows, '', false );
			return;
		}
		update_option( $this->index_key(), $rows, false );
	}

	private function index_exists(): bool {
		global $wpdb;
		if ( ! isset( $wpdb ) || ! is_object( $wpdb ) ) {
			return false;
		}
		$id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT option_id FROM {$wpdb->options} WHERE option_name = %s LIMIT 1",
				$this->index_key()
			)
		);
		return null !== $id && '' !== (string) $id;
	}
}
