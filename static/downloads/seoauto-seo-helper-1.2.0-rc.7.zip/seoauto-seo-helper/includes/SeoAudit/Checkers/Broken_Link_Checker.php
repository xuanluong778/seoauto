<?php
/**
 * Broken / blocked / timed-out link checker — read-only probes.
 *
 * @package SEOAuto\SEOHelper
 */

declare(strict_types=1);

namespace SEOAuto\SEOHelper\SeoAudit\Checkers;

use SEOAuto\SEOHelper\SeoAudit\Audit_Codes;
use SEOAuto\SEOHelper\SeoAudit\Audit_Issue;
use SEOAuto\SEOHelper\SeoAudit\Checker_Interface;
use SEOAuto\SEOHelper\SeoAudit\Object_Context;

final class Broken_Link_Checker implements Checker_Interface {

	public const MAX_CHECKS   = 3;
	public const TIMEOUT      = 5;
	public const REDIRECTS    = 5;
	public const MAX_RETRIES  = 1;

	public function id(): string {
		return 'broken_link';
	}

	public function check( Object_Context $ctx ): array {
		$findings = array(
			'404'     => array(),
			'403'     => array(),
			'429'     => array(),
			'timeout' => array(),
		);
		$checked = 0;
		$skipped = 0;

		foreach ( $ctx->links as $url ) {
			if ( $checked >= self::MAX_CHECKS ) {
				break;
			}
			$url = esc_url_raw( $url );
			if ( $url === '' || ! preg_match( '#^https?://#i', $url ) ) {
				continue;
			}
			if ( self::is_skip_host( $url ) ) {
				++$skipped;
				continue;
			}
			++$checked;
			$result = $this->probe( $url );
			$class  = $result['class'];
			if ( isset( $findings[ $class ] ) ) {
				$findings[ $class ][] = array(
					'url'    => $url,
					'code'   => $result['code'],
					'status' => $result['status'],
					'final'  => $result['final_url'],
				);
			}
		}

		$issues = array();
		if ( $findings['404'] !== array() ) {
			$issues[] = $this->make_issue(
				$ctx,
				Audit_Codes::BROKEN_LINK,
				Audit_Codes::SEVERITY_HIGH,
				Audit_Codes::RISK_SENSITIVE,
				$findings['404'],
				$checked,
				$skipped,
				__( 'Sửa hoặc gỡ link 404/410', 'seoauto-seo-helper' ),
				sprintf(
					/* translators: %d: count */
					__( 'Phát hiện %d link lỗi (404/410).', 'seoauto-seo-helper' ),
					count( $findings['404'] )
				)
			);
		}
		if ( $findings['403'] !== array() ) {
			$issues[] = $this->make_issue(
				$ctx,
				Audit_Codes::LINK_FORBIDDEN,
				Audit_Codes::SEVERITY_LOW,
				Audit_Codes::RISK_SAFE,
				$findings['403'],
				$checked,
				$skipped,
				__( 'Kiểm tra thủ công (có thể bị chặn bot)', 'seoauto-seo-helper' ),
				sprintf(
					/* translators: %d: count */
					__( '%d link trả 403 — không chắc là link chết.', 'seoauto-seo-helper' ),
					count( $findings['403'] )
				)
			);
		}
		if ( $findings['429'] !== array() ) {
			$issues[] = $this->make_issue(
				$ctx,
				Audit_Codes::LINK_RATE_LIMITED,
				Audit_Codes::SEVERITY_LOW,
				Audit_Codes::RISK_SAFE,
				$findings['429'],
				$checked,
				$skipped,
				__( 'Thử lại sau (rate limit)', 'seoauto-seo-helper' ),
				sprintf(
					/* translators: %d: count */
					__( '%d link bị giới hạn tốc độ (429).', 'seoauto-seo-helper' ),
					count( $findings['429'] )
				)
			);
		}
		if ( $findings['timeout'] !== array() ) {
			$issues[] = $this->make_issue(
				$ctx,
				Audit_Codes::LINK_TIMEOUT,
				Audit_Codes::SEVERITY_LOW,
				Audit_Codes::RISK_SAFE,
				$findings['timeout'],
				$checked,
				$skipped,
				__( 'Thử lại hoặc kiểm tra thủ công', 'seoauto-seo-helper' ),
				sprintf(
					/* translators: %d: count */
					__( '%d link timeout / không phản hồi.', 'seoauto-seo-helper' ),
					count( $findings['timeout'] )
				)
			);
		}

		return $issues;
	}

	/**
	 * Google Drive / Docs / Dropbox preview hosts often 403 bots — never false-flag as 404.
	 */
	public static function is_skip_host( string $url ): bool {
		$host = strtolower( (string) ( wp_parse_url( $url, PHP_URL_HOST ) ?: '' ) );
		if ( $host === '' ) {
			return false;
		}
		$skip = array(
			'drive.google.com',
			'docs.google.com',
			'drive.usercontent.google.com',
			'dropbox.com',
			'www.dropbox.com',
			'dl.dropboxusercontent.com',
		);
		foreach ( $skip as $h ) {
			if ( $host === $h || str_ends_with( $host, '.' . $h ) ) {
				return true;
			}
		}
		return (bool) apply_filters( 'seoauto_helper_audit_skip_link_host', false, $host, $url );
	}

	/**
	 * @param list<array{url:string,code:int,status:string,final:string}> $items
	 */
	private function make_issue(
		Object_Context $ctx,
		string $code,
		string $severity,
		string $risk,
		array $items,
		int $checked,
		int $skipped,
		string $suggest,
		string $message
	): Audit_Issue {
		$readable = array();
		foreach ( $items as $item ) {
			$readable[] = $item['url'] . ' → ' . $item['status'];
		}
		return new Audit_Issue(
			$code,
			$severity,
			$risk,
			$ctx->object_type,
			$ctx->object_id,
			implode( '; ', $readable ),
			$suggest,
			$message,
			Audit_Codes::STATUS_OPEN,
			array(
				'links'   => $items,
				'checked' => $checked,
				'skipped' => $skipped,
			)
		);
	}

	/**
	 * @return array{code:int,status:string,class:string,final_url:string}
	 */
	private function probe( string $url ): array {
		$attempt = 0;
		$last    = array(
			'code'      => 0,
			'status'    => 'timeout',
			'class'     => 'timeout',
			'final_url' => $url,
		);

		while ( $attempt <= self::MAX_RETRIES ) {
			++$attempt;
			$head = $this->request( 'HEAD', $url );
			if ( $head['ok'] ) {
				$class = $this->classify( $head['code'], false );
				// HEAD blocked → GET fallback.
				if ( in_array( $head['code'], array( 0, 403, 405, 501 ), true ) || 'timeout' === $class ) {
					$get = $this->request( 'GET', $url );
					if ( $get['ok'] ) {
						return $this->pack( $get['code'], $get['final_url'], false );
					}
					$last = $this->pack( 0, $url, true );
					if ( 'timeout' === $last['class'] && $attempt <= self::MAX_RETRIES ) {
						continue;
					}
					return $last;
				}
				return $this->pack( $head['code'], $head['final_url'], false );
			}

			// Transport error on HEAD → try GET once.
			$get = $this->request( 'GET', $url );
			if ( $get['ok'] ) {
				return $this->pack( $get['code'], $get['final_url'], false );
			}
			$last = $this->pack( 0, $url, true );
			if ( $attempt <= self::MAX_RETRIES ) {
				continue;
			}
			return $last;
		}

		return $last;
	}

	/**
	 * @return array{ok:bool,code:int,final_url:string,error:string}
	 */
	private function request( string $method, string $url ): array {
		$args = array(
			'timeout'     => self::TIMEOUT,
			'redirection' => self::REDIRECTS,
			'sslverify'   => true,
			'headers'     => array(
				'User-Agent' => 'SEOAuto-SEO-Helper-Audit/' . SEOAUTO_HELPER_VERSION,
			),
		);
		if ( 'GET' === $method ) {
			$args['headers']['Range'] = 'bytes=0-0';
			$response = wp_remote_get( $url, $args );
		} else {
			$response = wp_remote_head( $url, $args );
		}

		if ( is_wp_error( $response ) ) {
			return array(
				'ok'        => false,
				'code'      => 0,
				'final_url' => $url,
				'error'     => $response->get_error_code(),
			);
		}

		$code  = (int) wp_remote_retrieve_response_code( $response );
		$final = (string) wp_remote_retrieve_header( $response, 'x-final-location' );
		if ( $final === '' ) {
			// wp_remote follows redirects; use request URL as best-effort final.
			$final = $url;
		}

		return array(
			'ok'        => true,
			'code'      => $code,
			'final_url' => $final,
			'error'     => '',
		);
	}

	/**
	 * @return array{code:int,status:string,class:string,final_url:string}
	 */
	private function pack( int $code, string $final_url, bool $transport_error ): array {
		$class  = $this->classify( $code, $transport_error );
		$status = match ( $class ) {
			'404'     => (string) ( $code > 0 ? $code : 404 ),
			'403'     => '403',
			'429'     => '429',
			'timeout' => 'timeout',
			default   => (string) $code,
		};
		return array(
			'code'      => $code,
			'status'    => $status,
			'class'     => $class,
			'final_url' => $final_url,
		);
	}

	/**
	 * @return '404'|'403'|'429'|'timeout'|'ok'
	 */
	private function classify( int $code, bool $transport_error ): string {
		if ( $transport_error || 0 === $code ) {
			return 'timeout';
		}
		if ( in_array( $code, array( 404, 410 ), true ) ) {
			return '404';
		}
		if ( 403 === $code ) {
			return '403';
		}
		if ( 429 === $code ) {
			return '429';
		}
		if ( $code >= 200 && $code < 400 ) {
			return 'ok';
		}
		// Other 4xx/5xx: treat as soft timeout/unknown — do not call them 404.
		if ( $code >= 500 ) {
			return 'timeout';
		}
		return 'ok';
	}
}
