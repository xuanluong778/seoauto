<?php
/**
 * SEO Audit Engine — scan objects via checkers (read-only Phase 1).
 *
 * @package SEOAuto\SEOHelper
 */

declare(strict_types=1);

namespace SEOAuto\SEOHelper\SeoAudit;

use SEOAuto\SEOHelper\Seo\Seo_Facade;
use SEOAuto\SEOHelper\SeoAudit\Checkers\Broken_Link_Checker;
use SEOAuto\SEOHelper\SeoAudit\Checkers\Canonical_Checker;
use SEOAuto\SEOHelper\SeoAudit\Checkers\Featured_Image_Checker;
use SEOAuto\SEOHelper\SeoAudit\Checkers\Heading_Checker;
use SEOAuto\SEOHelper\SeoAudit\Checkers\Image_Alt_Checker;
use SEOAuto\SEOHelper\SeoAudit\Checkers\Internal_Link_Checker;
use SEOAuto\SEOHelper\SeoAudit\Checkers\Meta_Description_Checker;
use SEOAuto\SEOHelper\SeoAudit\Checkers\Mixed_Content_Checker;
use SEOAuto\SEOHelper\SeoAudit\Checkers\Robots_Checker;
use SEOAuto\SEOHelper\SeoAudit\Checkers\Schema_Checker;
use SEOAuto\SEOHelper\SeoAudit\Checkers\Sitemap_Checker;
use SEOAuto\SEOHelper\SeoAudit\Checkers\Thin_Content_Checker;
use SEOAuto\SEOHelper\SeoAudit\Checkers\Title_Checker;

final class Audit_Engine {

	public const BATCH_SIZE = 20;

	/** @var list<Checker_Interface> */
	private array $checkers;

	private Seo_Meta_Reader $reader;
	private Sitemap_Checker $sitemap;

	public function __construct(
		private Seo_Facade $seo,
		private Issue_Store $issues,
		private Audit_Run_Store $runs,
		?Seo_Meta_Reader $reader = null,
		/** @var list<Checker_Interface>|null */
		?array $checkers = null
	) {
		$this->reader  = $reader ?? new Seo_Meta_Reader( $this->seo );
		$this->sitemap = new Sitemap_Checker();
		$this->checkers = $checkers ?? array(
			new Title_Checker(),
			new Meta_Description_Checker(),
			new Heading_Checker(),
			new Image_Alt_Checker(),
			new Featured_Image_Checker(),
			new Internal_Link_Checker(),
			new Broken_Link_Checker(),
			new Canonical_Checker(),
			new Robots_Checker(),
			new Schema_Checker(),
			new Mixed_Content_Checker(),
			new Thin_Content_Checker(),
		);
	}

	/**
	 * @return list<string>
	 */
	public function checker_ids(): array {
		$ids = array_map( static fn( Checker_Interface $c ): string => $c->id(), $this->checkers );
		$ids[] = $this->sitemap->id();
		return $ids;
	}

	/**
	 * Count publishable objects for post types.
	 *
	 * @param list<string> $post_types
	 */
	public function count_objects( array $post_types ): int {
		$q = new \WP_Query(
			array(
				'post_type'              => $post_types,
				'post_status'            => array( 'publish', 'future', 'private' ),
				'posts_per_page'         => 1,
				'fields'                 => 'ids',
				'no_found_rows'          => false,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			)
		);
		return (int) $q->found_posts;
	}

	/**
	 * Fetch next batch after cursor (exclusive).
	 *
	 * @param list<string> $post_types
	 * @return list<\WP_Post>
	 */
	public function fetch_batch( array $post_types, int $cursor_id, int $batch_size = self::BATCH_SIZE ): array {
		// WP_Query lacks native cursor; use posts_where filter.
		$filter = static function ( string $where ) use ( $cursor_id ): string {
			global $wpdb;
			if ( $cursor_id > 0 ) {
				$where .= $wpdb->prepare( " AND {$wpdb->posts}.ID > %d", $cursor_id );
			}
			return $where;
		};
		add_filter( 'posts_where', $filter, 10, 1 );
		$q = new \WP_Query(
			array(
				'post_type'              => $post_types,
				'post_status'            => array( 'publish', 'future', 'private' ),
				'posts_per_page'         => max( 1, min( 50, $batch_size ) ),
				'orderby'                => 'ID',
				'order'                  => 'ASC',
				'ignore_sticky_posts'    => true,
				'no_found_rows'          => true,
				'update_post_meta_cache' => true,
				'update_post_term_cache' => false,
			)
		);
		remove_filter( 'posts_where', $filter, 10 );

		$posts = $q->posts;
		return is_array( $posts ) ? array_values( array_filter( $posts, static fn( $p ) => $p instanceof \WP_Post ) ) : array();
	}

	/**
	 * Scan one post-like object and upsert issues.
	 * Individual checker failures are isolated — they never abort the whole scan.
	 *
	 * @param \WP_Post|object $post
	 * @return array{issues:int,codes:list<string>,checker_errors:int}
	 */
	public function scan_post( int $run_id, object $post ): array {
		$ctx            = Object_Context::from_post( $post, $this->reader );
		$found          = array();
		$checker_errors = 0;
		foreach ( $this->checkers as $checker ) {
			try {
				foreach ( $checker->check( $ctx ) as $issue ) {
					$found[] = $issue;
				}
			} catch ( \Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch
				++$checker_errors;
				// Continue remaining checkers — do not fail the job on one broken checker.
			}
		}
		$saved = $this->issues->replace_for_object( $run_id, $ctx->object_type, $ctx->object_id, $found );
		return array(
			'issues'          => $saved,
			'codes'           => array_map( static fn( Audit_Issue $i ): string => $i->issue_code, $found ),
			'checker_errors'  => $checker_errors,
		);
	}

	/**
	 * Site-level checks (sitemap) — once per run.
	 */
	public function scan_site_level( int $run_id ): int {
		$issues = $this->sitemap->check_site();
		return $this->issues->replace_for_object( $run_id, 'site', 0, $issues );
	}

	/**
	 * Process one batch for a run. Returns progress snapshot.
	 *
	 * Marks run running immediately, then updates cursor/processed after each object
	 * so a slow checker or timeout cannot leave Job=running / Run=queued / 0 processed.
	 *
	 * @param array<string,mixed> $run
	 * @param callable|null       $on_progress Optional callback(array $snapshot): void after each object.
	 * @return array{done:bool,processed:int,cursor:int,issues_delta:int,cancelled:bool,processed_total:int,issues_found:int}
	 */
	public function process_batch( array $run, int $batch_size = self::BATCH_SIZE, ?callable $on_progress = null ): array {
		$run_id = (int) ( $run['id'] ?? 0 );
		if ( $run_id <= 0 ) {
			return array(
				'done'            => true,
				'processed'       => 0,
				'cursor'          => 0,
				'issues_delta'    => 0,
				'cancelled'       => false,
				'processed_total' => 0,
				'issues_found'    => 0,
			);
		}

		$fresh = $this->runs->get( $run_id );
		if ( null === $fresh || Audit_Run_Store::STATUS_CANCELLED === ( $fresh['status'] ?? '' ) ) {
			return array(
				'done'            => true,
				'processed'       => 0,
				'cursor'          => (int) ( $run['cursor_id'] ?? 0 ),
				'issues_delta'    => 0,
				'cancelled'       => true,
				'processed_total' => (int) ( $fresh['processed_objects'] ?? 0 ),
				'issues_found'    => (int) ( $fresh['issues_found'] ?? 0 ),
			);
		}

		/** @var list<string> $types */
		$types  = is_array( $fresh['post_types'] ?? null ) ? $fresh['post_types'] : Object_Context::audit_post_types();
		$cursor = (int) ( $fresh['cursor_id'] ?? 0 );
		$meta   = is_array( $fresh['meta'] ?? null ) ? $fresh['meta'] : array();
		$now    = gmdate( 'Y-m-d H:i:s' );

		// Sync Job↔Run: leave queued as soon as a worker starts the batch.
		$this->runs->update(
			$run_id,
			array(
				'status'      => Audit_Run_Store::STATUS_RUNNING,
				'started_gmt' => $fresh['started_gmt'] ?: $now,
				'seo_adapter' => $this->seo->active_id(),
			)
		);

		$issues_delta = 0;
		if ( empty( $meta['site_checked'] ) ) {
			try {
				$issues_delta += $this->scan_site_level( $run_id );
			} catch ( \Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch
				// Site-level failure must not stall the whole run.
			}
			$meta['site_checked'] = true;
			$this->runs->update(
				$run_id,
				array(
					'meta_json'    => wp_json_encode( $meta ),
					'issues_found' => $this->issues->count_for_run( $run_id ),
				)
			);
		}

		$posts = $this->fetch_batch( $types, $cursor, $batch_size );
		if ( $posts === array() ) {
			$total_issues = $this->issues->count_for_run( $run_id );
			$this->runs->update(
				$run_id,
				array(
					'status'       => Audit_Run_Store::STATUS_COMPLETED,
					'issues_found' => $total_issues,
					'finished_gmt' => gmdate( 'Y-m-d H:i:s' ),
					'meta_json'    => wp_json_encode( $meta ),
					'seo_adapter'  => $this->seo->active_id(),
				)
			);
			return array(
				'done'            => true,
				'processed'       => 0,
				'cursor'          => $cursor,
				'issues_delta'    => $issues_delta,
				'cancelled'       => false,
				'processed_total' => (int) ( $fresh['processed_objects'] ?? 0 ),
				'issues_found'    => $total_issues,
			);
		}

		$processed     = 0;
		$last_id       = $cursor;
		$new_processed = (int) ( $fresh['processed_objects'] ?? 0 );
		foreach ( $posts as $post ) {
			try {
				$result = $this->scan_post( $run_id, $post );
				$issues_delta += (int) $result['issues'];
			} catch ( \Throwable $e ) {
				// Object-level hard failure: skip object, keep scanning.
			}
			$last_id = (int) $post->ID;
			++$processed;
			++$new_processed;
			$total_issues = $this->issues->count_for_run( $run_id );
			$this->runs->update(
				$run_id,
				array(
					'status'            => Audit_Run_Store::STATUS_RUNNING,
					'cursor_id'         => $last_id,
					'processed_objects' => $new_processed,
					'issues_found'      => $total_issues,
					'meta_json'         => wp_json_encode( $meta ),
					'seo_adapter'       => $this->seo->active_id(),
				)
			);
			if ( null !== $on_progress ) {
				$on_progress(
					array(
						'cursor'          => $last_id,
						'processed'       => $processed,
						'processed_total' => $new_processed,
						'issues_found'    => $total_issues,
						'issues_delta'    => $issues_delta,
					)
				);
			}
		}

		$done = count( $posts ) < $batch_size;
		if ( $done ) {
			$this->runs->update(
				$run_id,
				array(
					'status'       => Audit_Run_Store::STATUS_COMPLETED,
					'finished_gmt' => gmdate( 'Y-m-d H:i:s' ),
					'issues_found' => $this->issues->count_for_run( $run_id ),
				)
			);
		}

		return array(
			'done'            => $done,
			'processed'       => $processed,
			'cursor'          => $last_id,
			'issues_delta'    => $issues_delta,
			'cancelled'       => false,
			'processed_total' => $new_processed,
			'issues_found'    => $this->issues->count_for_run( $run_id ),
		);
	}
}
