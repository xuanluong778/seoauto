<?php
/**
 * Normalized object context for checkers.
 *
 * @package SEOAuto\SEOHelper
 */

declare(strict_types=1);

namespace SEOAuto\SEOHelper\SeoAudit;

final class Object_Context {

	/**
	 * @param array<string,mixed> $seo
	 * @param list<array{src:string,alt:string}> $images
	 * @param list<string> $links
	 * @param list<array{tag:string,text:string}> $headings
	 * @param list<string> $content_sources
	 */
	public function __construct(
		public int $object_id,
		public string $object_type,
		public string $post_status,
		public string $title,
		public string $content_html,
		public string $content_text,
		public int $word_count,
		public string $permalink,
		public bool $has_featured_image,
		public array $seo,
		public array $images,
		public array $links,
		public array $headings,
		public string $seo_adapter,
		public array $content_sources = array()
	) {}

	/**
	 * @return list<string>
	 */
	public static function audit_post_types(): array {
		$types = array( 'post', 'page' );
		if ( class_exists( '\\WooCommerce' ) || post_type_exists( 'product' ) ) {
			$types[] = 'product';
		}
		/** @var list<string> $types */
		$types = apply_filters( 'seoauto_helper_audit_post_types', $types );
		return array_values( array_unique( array_map( 'sanitize_key', $types ) ) );
	}

	/**
	 * @param \WP_Post|object $post Post-like object with ID, post_type, post_status, post_title, post_content.
	 */
	public static function from_post( object $post, Seo_Meta_Reader $reader ): self {
		$id       = (int) ( $post->ID ?? 0 );
		$extracted = Content_Text_Extractor::extract( $post );
		$seo       = $reader->read( $id );

		return new self(
			$id,
			(string) ( $post->post_type ?? 'post' ),
			(string) ( $post->post_status ?? 'publish' ),
			(string) ( $post->post_title ?? '' ),
			(string) $extracted['html'],
			(string) $extracted['text'],
			(int) $extracted['word_count'],
			(string) get_permalink( $post ),
			has_post_thumbnail( $post ),
			$seo,
			$extracted['images'],
			$extracted['links'],
			$extracted['headings'],
			(string) ( $seo['adapter'] ?? 'native' ),
			$extracted['sources']
		);
	}
}
