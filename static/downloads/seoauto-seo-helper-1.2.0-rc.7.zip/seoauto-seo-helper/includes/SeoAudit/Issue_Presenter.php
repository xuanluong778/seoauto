<?php
/**
 * Human-readable presentation for audit issues (admin UI).
 * Read-only — never mutates posts.
 *
 * @package SEOAuto\SEOHelper
 */

declare(strict_types=1);

namespace SEOAuto\SEOHelper\SeoAudit;

final class Issue_Presenter {

	/**
	 * @param array<string,mixed> $issue Row from Issue_Store.
	 * @return array{
	 *   severity:string,
	 *   code:string,
	 *   object_type:string,
	 *   object_id:int,
	 *   title:string,
	 *   url:string,
	 *   type_label:string,
	 *   current:string,
	 *   suggested:string,
	 *   risk:string,
	 *   status:string,
	 *   view_url:string,
	 *   edit_url:string,
	 *   message:string
	 * }
	 */
	public static function present( array $issue ): array {
		$object_type = sanitize_key( (string) ( $issue['object_type'] ?? 'post' ) );
		$object_id   = (int) ( $issue['object_id'] ?? 0 );
		$code        = (string) ( $issue['issue_code'] ?? '' );

		$title = '';
		$url   = '';
		if ( $object_id > 0 && in_array( $object_type, array( 'post', 'page', 'product' ), true ) ) {
			$title = (string) get_the_title( $object_id );
			$url   = (string) get_permalink( $object_id );
		} elseif ( $object_type === 'site' ) {
			$title = (string) get_bloginfo( 'name' );
			$url   = (string) home_url( '/' );
		}
		if ( $title === '' ) {
			$title = sprintf( '%s #%d', $object_type, $object_id );
		}

		$ctx = array();
		if ( ! empty( $issue['context'] ) && is_array( $issue['context'] ) ) {
			$ctx = $issue['context'];
		} elseif ( ! empty( $issue['context_json'] ) ) {
			$decoded = json_decode( (string) $issue['context_json'], true );
			$ctx     = is_array( $decoded ) ? $decoded : array();
		}

		$current   = self::format_current( $code, (string) ( $issue['current_value'] ?? '' ), $ctx );
		$suggested = self::format_suggested( $code, (string) ( $issue['suggested_value'] ?? '' ) );

		$view = $url;
		$edit = '';
		if ( $object_id > 0 && post_type_exists( $object_type ) ) {
			$edit_link = get_edit_post_link( $object_id, 'raw' );
			$edit      = is_string( $edit_link ) ? $edit_link : '';
			if ( $view === '' ) {
				$view = (string) get_permalink( $object_id );
			}
		}

		return array(
			'severity'   => (string) ( $issue['severity'] ?? '' ),
			'code'       => $code,
			'object_type'=> $object_type,
			'object_id'  => $object_id,
			'title'      => $title,
			'url'        => $url,
			'type_label' => self::type_label( $object_type ),
			'current'    => $current,
			'suggested'  => $suggested,
			'risk'       => (string) ( $issue['risk_level'] ?? '' ),
			'status'     => (string) ( $issue['status'] ?? '' ),
			'view_url'   => $view,
			'edit_url'   => $edit,
			'message'    => (string) ( $issue['message'] ?? '' ),
		);
	}

	private static function type_label( string $type ): string {
		return match ( $type ) {
			'post'    => __( 'Bài viết', 'seoauto-seo-helper' ),
			'page'    => __( 'Trang', 'seoauto-seo-helper' ),
			'product' => __( 'Sản phẩm', 'seoauto-seo-helper' ),
			'site'    => __( 'Toàn site', 'seoauto-seo-helper' ),
			default   => $type,
		};
	}

	/**
	 * @param array<string,mixed> $ctx
	 */
	private static function format_current( string $code, string $raw, array $ctx ): string {
		// Prefer structured link lists over raw JSON.
		if ( ! empty( $ctx['links'] ) && is_array( $ctx['links'] ) ) {
			$parts = array();
			foreach ( $ctx['links'] as $row ) {
				if ( ! is_array( $row ) ) {
					continue;
				}
				$u = (string) ( $row['url'] ?? '' );
				$s = (string) ( $row['status'] ?? ( $row['code'] ?? '' ) );
				if ( $u === '' ) {
					continue;
				}
				$parts[] = $u . ' → ' . $s;
			}
			if ( $parts !== array() ) {
				return implode( '; ', $parts );
			}
		}
		if ( ! empty( $ctx['broken'] ) && is_array( $ctx['broken'] ) ) {
			$parts = array();
			foreach ( $ctx['broken'] as $row ) {
				if ( ! is_array( $row ) ) {
					continue;
				}
				$parts[] = (string) ( $row['url'] ?? '' ) . ' → ' . (string) ( $row['code'] ?? '404' );
			}
			if ( $parts !== array() ) {
				return implode( '; ', $parts );
			}
		}

		$trim = trim( $raw );
		if ( $trim !== '' && ( str_starts_with( $trim, '[' ) || str_starts_with( $trim, '{' ) ) ) {
			$decoded = json_decode( $trim, true );
			if ( is_array( $decoded ) ) {
				return self::stringify_jsonish( $decoded );
			}
		}

		if ( Audit_Codes::THIN_CONTENT === $code ) {
			$n = (int) ( $ctx['word_count'] ?? $raw );
			return sprintf(
				/* translators: %d: word count */
				__( '%d từ', 'seoauto-seo-helper' ),
				$n
			);
		}
		if ( Audit_Codes::FEATURED_MISSING === $code && ( $trim === '' || $trim === 'none' ) ) {
			return __( 'Không có', 'seoauto-seo-helper' );
		}
		if ( Audit_Codes::DESC_MISSING === $code && $trim === '' ) {
			return __( '(trống)', 'seoauto-seo-helper' );
		}

		return $trim === '' ? '—' : mb_substr( $trim, 0, 160 );
	}

	private static function format_suggested( string $code, string $raw ): string {
		$trim = trim( $raw );
		if ( Audit_Codes::THIN_CONTENT === $code ) {
			return __( '≥ 300 từ', 'seoauto-seo-helper' );
		}
		if ( $trim === '' ) {
			return '—';
		}
		if ( str_starts_with( $trim, '[' ) || str_starts_with( $trim, '{' ) ) {
			$decoded = json_decode( $trim, true );
			if ( is_array( $decoded ) ) {
				return self::stringify_jsonish( $decoded );
			}
		}
		return mb_substr( $trim, 0, 160 );
	}

	/**
	 * @param array<mixed> $data
	 */
	private static function stringify_jsonish( array $data ): string {
		$parts = array();
		foreach ( $data as $row ) {
			if ( is_array( $row ) && isset( $row['url'] ) ) {
				$parts[] = (string) $row['url'] . ( isset( $row['code'] ) ? ' → ' . $row['code'] : '' );
			} elseif ( is_string( $row ) ) {
				$parts[] = $row;
			}
		}
		if ( $parts !== array() ) {
			return implode( '; ', $parts );
		}
		$json = wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		return is_string( $json ) ? mb_substr( $json, 0, 120 ) : '—';
	}
}
