<?php
/**
 * Extract readable HTML/text from classic, Gutenberg, shortcode, and page-builder content.
 * Read-only — never updates posts or meta.
 *
 * @package SEOAuto\SEOHelper
 */

declare(strict_types=1);

namespace SEOAuto\SEOHelper\SeoAudit;

final class Content_Text_Extractor {

	/**
	 * @param \WP_Post|object $post
	 * @return array{
	 *   html:string,
	 *   text:string,
	 *   word_count:int,
	 *   images:list<array{src:string,alt:string}>,
	 *   links:list<string>,
	 *   headings:list<array{tag:string,text:string}>,
	 *   sources:list<string>
	 * }
	 */
	public static function extract( object $post ): array {
		$id      = (int) ( $post->ID ?? 0 );
		$sources = array();
		$parts   = array();

		$raw = (string) ( $post->post_content ?? '' );
		if ( $raw !== '' ) {
			$parts[]   = self::normalize_gutenberg( $raw );
			$sources[] = 'post_content';
		}

		// Shortcodes often wrap builder/widgets — expand only when raw looks shortcode-heavy.
		if ( $raw !== '' && self::looks_like_shortcodes( $raw ) ) {
			$expanded = self::safe_do_shortcode( $raw );
			if ( $expanded !== '' && $expanded !== $raw ) {
				$parts[]   = $expanded;
				$sources[] = 'shortcode';
			}
		}

		if ( $id > 0 ) {
			$elementor = self::extract_elementor_html( $id );
			if ( $elementor !== '' ) {
				$parts[]   = $elementor;
				$sources[] = 'elementor';
			}

			// Other builders that stash HTML in common meta keys (read-only).
			foreach ( array( '_wpb_shortcodes_custom_css', 'panels_data' ) as $ignored ) {
				unset( $ignored );
			}
			$bb = self::extract_beaver_text( $id );
			if ( $bb !== '' ) {
				$parts[]   = $bb;
				$sources[] = 'beaver';
			}
		}

		$html = trim( implode( "\n", array_filter( $parts ) ) );
		$text = self::html_to_text( $html );

		// Last resort: excerpt / title should not inflate word count for thin_content,
		// but empty builder pages sometimes only have rendered widgets — already covered.

		return array(
			'html'       => $html,
			'text'       => $text,
			'word_count' => self::count_words( $text ),
			'images'     => self::extract_images( $html ),
			'links'      => self::extract_links( $html ),
			'headings'   => self::extract_headings( $html ),
			'sources'    => array_values( array_unique( $sources ) ),
		);
	}

	/**
	 * Count words for Vietnamese + Latin (Unicode letters/numbers).
	 */
	public static function count_words( string $text ): int {
		$text = trim( preg_replace( '/\s+/u', ' ', $text ) ?? '' );
		if ( $text === '' ) {
			return 0;
		}
		if ( preg_match_all( '/[\p{L}\p{N}]+(?:[\'’\-][\p{L}\p{N}]+)*/u', $text, $m ) ) {
			return count( $m[0] );
		}
		return 0;
	}

	public static function html_to_text( string $html ): string {
		if ( $html === '' ) {
			return '';
		}
		// Drop scripts/styles/noscript before stripping tags.
		$html = preg_replace( '#<(script|style|noscript)\b[^>]*>.*?</\1>#is', ' ', $html ) ?? $html;
		$html = preg_replace( '#<!--.*?-->#s', ' ', $html ) ?? $html;
		$text = wp_strip_all_tags( $html, true );
		$text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$text = preg_replace( '/\s+/u', ' ', $text ?? '' ) ?? '';
		return trim( $text );
	}

	/**
	 * Remove Gutenberg block comment markers; keep inner HTML.
	 */
	public static function normalize_gutenberg( string $html ): string {
		$html = preg_replace( '/<!--\s+wp:[^>]+-->/', '', $html ) ?? $html;
		$html = preg_replace( '/<!--\s+\/wp:[^>]+-->/', '', $html ) ?? $html;
		return $html;
	}

	private static function looks_like_shortcodes( string $html ): bool {
		return (bool) preg_match( '/\[[a-zA-Z][^\]]*\]/', $html );
	}

	private static function safe_do_shortcode( string $html ): string {
		if ( ! function_exists( 'do_shortcode' ) ) {
			return strip_shortcodes( $html );
		}
		try {
			return (string) do_shortcode( $html );
		} catch ( \Throwable $e ) {
			return strip_shortcodes( $html );
		}
	}

	/**
	 * Walk Elementor `_elementor_data` JSON and collect widget text/HTML.
	 */
	public static function extract_elementor_html( int $post_id ): string {
		$raw = get_post_meta( $post_id, '_elementor_data', true );
		if ( ! is_string( $raw ) || $raw === '' ) {
			return '';
		}
		$data = json_decode( $raw, true );
		if ( ! is_array( $data ) ) {
			// Occasionally double-encoded.
			$data = json_decode( stripslashes( $raw ), true );
		}
		if ( ! is_array( $data ) ) {
			return '';
		}
		$chunks = array();
		self::walk_elementor( $data, $chunks );
		return implode( "\n", $chunks );
	}

	/**
	 * @param list<mixed>       $nodes
	 * @param list<string>      $chunks
	 */
	private static function walk_elementor( array $nodes, array &$chunks ): void {
		foreach ( $nodes as $node ) {
			if ( ! is_array( $node ) ) {
				continue;
			}
			$settings = is_array( $node['settings'] ?? null ) ? $node['settings'] : array();
			foreach ( array( 'editor', 'title', 'text', 'description', 'caption', 'alert_title', 'alert_description', 'testimonial_content', 'tab_title', 'accordion_title', 'item_description', 'html' ) as $key ) {
				if ( empty( $settings[ $key ] ) || ! is_string( $settings[ $key ] ) ) {
					continue;
				}
				$val = trim( $settings[ $key ] );
				if ( $val !== '' ) {
					$chunks[] = $val;
				}
			}
			// Icon list / repeater-ish.
			foreach ( array( 'tabs', 'tabs_content', 'icon_list', 'list_items' ) as $rep ) {
				if ( empty( $settings[ $rep ] ) || ! is_array( $settings[ $rep ] ) ) {
					continue;
				}
				foreach ( $settings[ $rep ] as $row ) {
					if ( ! is_array( $row ) ) {
						continue;
					}
					foreach ( array( 'tab_title', 'tab_content', 'text', 'title', 'content', 'description' ) as $k ) {
						if ( ! empty( $row[ $k ] ) && is_string( $row[ $k ] ) ) {
							$chunks[] = $row[ $k ];
						}
					}
				}
			}
			if ( ! empty( $node['elements'] ) && is_array( $node['elements'] ) ) {
				self::walk_elementor( $node['elements'], $chunks );
			}
		}
	}

	private static function extract_beaver_text( int $post_id ): string {
		$data = get_post_meta( $post_id, '_fl_builder_data', true );
		if ( ! is_array( $data ) && ! is_string( $data ) ) {
			return '';
		}
		if ( is_string( $data ) ) {
			$decoded = json_decode( $data, true );
			$data    = is_array( $decoded ) ? $decoded : array();
		}
		$chunks = array();
		self::walk_beaver( $data, $chunks );
		return implode( "\n", $chunks );
	}

	/**
	 * @param array<string,mixed> $data
	 * @param list<string>        $chunks
	 */
	private static function walk_beaver( array $data, array &$chunks ): void {
		foreach ( $data as $node ) {
			if ( ! is_object( $node ) && ! is_array( $node ) ) {
				continue;
			}
			$arr = (array) $node;
			$settings = $arr['settings'] ?? null;
			if ( is_object( $settings ) || is_array( $settings ) ) {
				$s = (array) $settings;
				foreach ( array( 'text', 'editor', 'heading', 'content' ) as $k ) {
					if ( ! empty( $s[ $k ] ) && is_string( $s[ $k ] ) ) {
						$chunks[] = $s[ $k ];
					}
				}
			}
		}
	}

	/**
	 * @return list<array{src:string,alt:string}>
	 */
	public static function extract_images( string $html ): array {
		$images = array();
		if ( $html === '' || ! preg_match_all( '/<img\b[^>]*>/i', $html, $img_tags ) ) {
			return $images;
		}
		foreach ( $img_tags[0] as $tag ) {
			$src = '';
			$alt = '';
			if ( preg_match( '/\bsrc=["\']([^"\']+)["\']/i', $tag, $m ) ) {
				$src = html_entity_decode( $m[1], ENT_QUOTES | ENT_HTML5 );
			}
			if ( preg_match( '/\balt=["\']([^"\']*)["\']/i', $tag, $m ) ) {
				$alt = html_entity_decode( $m[1], ENT_QUOTES | ENT_HTML5 );
			} elseif ( ! preg_match( '/\balt=/i', $tag ) ) {
				$alt = '';
			}
			if ( $src !== '' ) {
				$images[] = array(
					'src' => $src,
					'alt' => $alt,
				);
			}
		}
		return $images;
	}

	/**
	 * @return list<string>
	 */
	public static function extract_links( string $html ): array {
		$links = array();
		if ( $html === '' || ! preg_match_all( '/<a\b[^>]*\bhref=["\']([^"\']+)["\']/i', $html, $hrefs ) ) {
			return $links;
		}
		foreach ( $hrefs[1] as $href ) {
			$href = html_entity_decode( (string) $href, ENT_QUOTES | ENT_HTML5 );
			if ( $href === '' || str_starts_with( $href, '#' ) ) {
				continue;
			}
			$lower = strtolower( $href );
			if ( str_starts_with( $lower, 'mailto:' ) || str_starts_with( $lower, 'tel:' ) || str_starts_with( $lower, 'javascript:' ) ) {
				continue;
			}
			$links[] = $href;
		}
		return array_values( array_unique( $links ) );
	}

	/**
	 * @return list<array{tag:string,text:string}>
	 */
	public static function extract_headings( string $html ): array {
		$headings = array();
		if ( $html === '' || ! preg_match_all( '/<(h[1-6])\b[^>]*>(.*?)<\/\1>/is', $html, $hs, PREG_SET_ORDER ) ) {
			return $headings;
		}
		foreach ( $hs as $h ) {
			$headings[] = array(
				'tag'  => strtolower( $h[1] ),
				'text' => trim( wp_strip_all_tags( $h[2] ) ),
			);
		}
		return $headings;
	}
}
