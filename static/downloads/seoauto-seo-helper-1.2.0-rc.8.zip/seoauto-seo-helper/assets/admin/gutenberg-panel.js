/**
 * Gutenberg panel — uses localized seoautoHelperEditor; admin only.
 */
(function (wp) {
  if (!wp || !wp.plugins || !window.seoautoHelperEditor) return;
  if (!seoautoHelperEditor.publishGuard && !seoautoHelperEditor.aiAssistant) return;

  var registerPlugin = wp.plugins.registerPlugin;
  var PluginDocumentSettingPanel = wp.editPost.PluginDocumentSettingPanel;
  var el = wp.element.createElement;
  var Button = wp.components.Button;
  var useState = wp.element.useState;

  function Panel() {
    var state = useState('');
    var msg = state[0];
    var setMsg = state[1];

    function collect() {
      var ed = wp.data.select('core/editor');
      return {
        action: 'seoauto_helper_pg_check',
        nonce: seoautoHelperEditor.nonce,
        post_id: ed.getCurrentPostId(),
        post_type: ed.getCurrentPostType(),
        post_status: ed.getEditedPostAttribute('status'),
        title: ed.getEditedPostAttribute('title') || '',
        content: ed.getEditedPostAttribute('content') || '',
        excerpt: ed.getEditedPostAttribute('excerpt') || ''
      };
    }

    function post(action, extra) {
      var body = Object.assign(collect(), extra || {}, { action: action });
      var form = new FormData();
      Object.keys(body).forEach(function (k) { form.append(k, body[k] == null ? '' : body[k]); });
      return fetch(seoautoHelperEditor.ajaxUrl, { method: 'POST', body: form, credentials: 'same-origin' })
        .then(function (r) { return r.json(); });
    }

    return el(
      PluginDocumentSettingPanel,
      { name: 'seoauto-helper-panel', title: 'SEOAuto Guard / AI', className: 'seoauto-helper-gutenberg' },
      seoautoHelperEditor.publishGuard && el(Button, {
        isSecondary: true,
        onClick: function () {
          setMsg(seoautoHelperEditor.i18n.checking);
          post('seoauto_helper_pg_check').then(function (res) {
            if (res && res.success) {
              var n = (res.data.issues || []).length;
              setMsg(n + ' cảnh báo · ' + (res.data.elapsed_ms || '?') + 'ms · không chặn đăng');
              post('seoauto_helper_pg_intent');
            } else {
              setMsg((res && res.data && res.data.message) || 'Lỗi');
            }
          });
        }
      }, 'Publish Guard'),
      seoautoHelperEditor.aiAssistant && el(Button, {
        isSecondary: true,
        style: { marginLeft: '8px' },
        onClick: function () {
          setMsg(seoautoHelperEditor.i18n.suggest);
          post('seoauto_helper_ai_suggest').then(function (res) {
            if (res && res.success) setMsg('AI job ' + (res.data.job_id || '') + ' · async');
            else setMsg((res && res.data && res.data.message) || 'AI lỗi');
          });
        }
      }, 'AI SEO'),
      el('p', { className: 'description' }, msg || seoautoHelperEditor.i18n.noBlock)
    );
  }

  registerPlugin('seoauto-helper-editor', { render: Panel });
})(window.wp);
