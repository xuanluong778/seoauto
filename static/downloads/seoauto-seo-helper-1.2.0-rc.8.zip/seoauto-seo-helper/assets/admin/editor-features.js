/**
 * SEOAuto editor features — admin only (Publish Guard + AI Assistant).
 */
(function ($) {
  'use strict';
  if (typeof seoautoHelperEditor === 'undefined') return;

  function draftPayload($root) {
    var postId = parseInt($root.data('post-id') || $('#post_ID').val() || 0, 10);
    var title = $('#title').val() || '';
    var content = '';
    if (typeof tinymce !== 'undefined' && tinymce.get('content')) {
      content = tinymce.get('content').getContent();
    } else {
      content = $('#content').val() || '';
    }
    return {
      action: '',
      nonce: seoautoHelperEditor.nonce,
      post_id: postId,
      post_type: $('#post_type').val() || 'post',
      post_status: $('#post_status').val() || 'draft',
      title: title,
      content: content,
      excerpt: $('#excerpt').val() || ''
    };
  }

  function renderIssues($box, data) {
    var issues = (data && data.issues) || [];
    if (!issues.length) {
      $box.html('<p class="seoauto-ok">Không có cảnh báo local.</p>');
      return;
    }
    var html = '<ul class="seoauto-issue-list">';
    issues.forEach(function (i) {
      html += '<li><strong>' + (i.severity || '') + '</strong> ' + (i.message || i.code) + '</li>';
    });
    html += '</ul><p class="description">' + (seoautoHelperEditor.i18n.noBlock || '') + '</p>';
    html += '<p><button type="button" class="button seoauto-pg-dismiss">'+ (seoautoHelperEditor.i18n.dismiss || 'Dismiss') +'</button></p>';
    $box.html(html);
  }

  $(document).on('click', '.seoauto-pg-run', function (e) {
    e.preventDefault();
    var $root = $('#seoauto-helper-classic-panel');
    var $box = $root.find('.seoauto-editor-results');
    $box.text(seoautoHelperEditor.i18n.checking || '…');
    var payload = draftPayload($root);
    payload.action = 'seoauto_helper_pg_check';
    $.post(seoautoHelperEditor.ajaxUrl, payload).done(function (res) {
      if (res && res.success) renderIssues($box, res.data);
      else $box.text((res && res.data && res.data.message) || 'Error');
      // Fire async intent without blocking publish.
      var intent = $.extend({}, payload, { action: 'seoauto_helper_pg_intent' });
      $.post(seoautoHelperEditor.ajaxUrl, intent);
    });
  });

  $(document).on('click', '.seoauto-pg-dismiss', function (e) {
    e.preventDefault();
    var $root = $('#seoauto-helper-classic-panel');
    $.post(seoautoHelperEditor.ajaxUrl, {
      action: 'seoauto_helper_pg_dismiss',
      nonce: seoautoHelperEditor.nonce,
      post_id: draftPayload($root).post_id,
      codes: [],
      note: 'user_dismissed'
    });
  });

  $(document).on('click', '.seoauto-ai-run', function (e) {
    e.preventDefault();
    var $root = $('#seoauto-helper-classic-panel');
    var $box = $root.find('.seoauto-editor-results');
    $box.text(seoautoHelperEditor.i18n.suggest || '…');
    var payload = draftPayload($root);
    payload.action = 'seoauto_helper_ai_suggest';
    $.post(seoautoHelperEditor.ajaxUrl, payload).done(function (res) {
      if (res && res.success) {
        $box.html('<p>AI job: ' + (res.data.job_id || '') + ' (' + (res.data.status || '') + ')</p>');
      } else {
        $box.text((res && res.data && res.data.message) || 'AI unavailable');
      }
    });
  });
})(jQuery);
