<?php
/**
 * Outbound HMAC requests to SEOAuto SaaS (reuse connection credentials).
 *
 * @package SEOAuto\SEOHelper
 */

declare(strict_types=1);

namespace SEOAuto\SEOHelper\Connection;

use SEOAuto\SEOHelper\Auth\Hmac_Signer;
use WP_Error;

final class SaaS_Request {

	public function __construct( private Connection_Manager $connection ) {}

	/**
	 * @param array<string,string> $extra_headers
	 * @return array{code:int,body:array<string,mixed>,raw:string}|WP_Error
	 */
	public function request( string $method, string $api_path, string $body = '', array $extra_headers = array(), int $timeout = 15 ): array|WP_Error {
		if ( ! $this->connection->has_credentials() ) {
			return new WP_Error( 'seoauto_not_paired', __( 'Site chưa ghép nối SEOAuto.', 'seoauto-seo-helper' ), array( 'status' => 401 ) );
		}
		$secret = $this->connection->site_secret();
		if ( $secret === '' ) {
			return new WP_Error( 'seoauto_missing_secret', __( 'Thiếu site secret.', 'seoauto-seo-helper' ), array( 'status' => 401 ) );
		}

		$path    = Hmac_Signer::normalize_path( $api_path );
		$url     = $this->connection->api_base() . $path;
		$headers = Hmac_Signer::build_headers(
			$this->connection->site_id(),
			(int) $this->connection->option( 'connection_id', 0 ),
			$secret,
			strtoupper( $method ),
			$path,
			$body
		);
		$secret = '';

		$args = array(
			'timeout'   => max( 5, min( 60, $timeout ) ),
			'sslverify' => true,
			'headers'   => array_merge(
				$headers,
				array( 'Content-Type' => 'application/json', 'Accept' => 'application/json' ),
				$extra_headers
			),
			'method'    => strtoupper( $method ),
		);
		if ( $body !== '' && strtoupper( $method ) !== 'GET' ) {
			$args['body'] = $body;
		}

		$response = wp_remote_request( $url, $args );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$raw  = (string) wp_remote_retrieve_body( $response );
		$data = json_decode( $raw, true );
		if ( ! is_array( $data ) ) {
			$data = array();
		}
		if ( $code >= 400 ) {
			$msg = (string) ( $data['detail']['message'] ?? $data['message'] ?? $data['detail'] ?? ( 'HTTP ' . $code ) );
			if ( is_array( $msg ) ) {
				$msg = wp_json_encode( $msg );
			}
			return new WP_Error(
				'seoauto_saas_http_' . $code,
				$msg,
				array(
					'status' => $code,
					'body'   => $data,
				)
			);
		}
		return array(
			'code' => $code,
			'body' => $data,
			'raw'  => $raw,
		);
	}
}
