<?php
/**
 * AI SEO Assistant — suggest (async SaaS) + apply via ContentOps.
 *
 * @package SEOAuto\SEOHelper
 */

declare(strict_types=1);

namespace SEOAuto\SEOHelper\AiSeo;

use SEOAuto\SEOHelper\Audit\Audit_Logger;
use SEOAuto\SEOHelper\Connection\Connection_Manager;
use SEOAuto\SEOHelper\ContentOps\ContentOps_Service;
use SEOAuto\SEOHelper\Entitlement\Entitlement_Manager;
use SEOAuto\SEOHelper\Seo\Seo_Facade;
use WP_Error;

final class Ai_Seo_Assistant_Service {

	public const FEATURE = 'ai_seo_assistant';

	private Ai_Suggest_Client $client;
	private Ai_Apply_Service $apply;

	public function __construct(
		private Connection_Manager $connection,
		private Entitlement_Manager $entitlement,
		private ContentOps_Service $content_ops,
		private Seo_Facade $seo,
		private Audit_Logger $audit,
		?Ai_Suggest_Client $client = null,
		?Ai_Apply_Service $apply = null
	) {
		$this->client = $client ?? new Ai_Suggest_Client( $connection );
		$this->apply  = $apply ?? new Ai_Apply_Service( $content_ops, $seo, $audit );
	}

	public function is_enabled(): bool {
		return $this->entitlement->has_feature( self::FEATURE )
			&& $this->entitlement->has_feature( ContentOps_Service::FEATURE )
			&& ! $this->entitlement->is_locked()
			&& $this->connection->has_credentials();
	}

	/**
	 * @param array<string,mixed> $payload
	 * @return array<string,mixed>|WP_Error
	 */
	public function suggest( array $payload ): array|WP_Error {
		if ( ! $this->is_enabled() ) {
			return new WP_Error(
				'seoauto_feature_denied',
				__( 'Thiếu feature: ai_seo_assistant (và content_ops).', 'seoauto-seo-helper' ),
				array( 'status' => 403, 'code' => 'seoauto_feature_denied' )
			);
		}
		$res = $this->client->enqueue( $payload );
		if ( $res instanceof WP_Error ) {
			$this->audit->log_error( 'ai_seo_suggest_enqueue', $res->get_error_code(), array( 'post_id' => (int) ( $payload['post_id'] ?? 0 ) ) );
			return $res;
		}
		$this->audit->log(
			'ai_seo_suggest_enqueue',
			array(
				'post_id'    => (int) ( $payload['post_id'] ?? 0 ),
				'job_id'     => (string) ( $res['job_id'] ?? '' ),
				'request_id' => (string) ( $res['request_id'] ?? '' ),
				'status'     => 'queued',
			)
		);
		return $res;
	}

	/**
	 * @return array<string,mixed>|WP_Error
	 */
	public function suggest_status( string $job_id ): array|WP_Error {
		if ( ! $this->is_enabled() ) {
			return new WP_Error( 'seoauto_feature_denied', __( 'Thiếu feature: ai_seo_assistant.', 'seoauto-seo-helper' ), array( 'status' => 403 ) );
		}
		return $this->client->status( $job_id );
	}

	/**
	 * @param array<string,mixed> $suggestions
	 * @return array<string,mixed>|WP_Error
	 */
	public function apply( int $post_id, array $suggestions, string $request_id = '' ): array|WP_Error {
		if ( ! $this->is_enabled() ) {
			return new WP_Error( 'seoauto_feature_denied', __( 'Thiếu feature: ai_seo_assistant.', 'seoauto-seo-helper' ), array( 'status' => 403 ) );
		}
		return $this->apply->apply_via_content_ops( $post_id, $suggestions, $request_id );
	}

	/**
	 * @return array<string,mixed>|WP_Error
	 */
	public function rollback( int $batch_id ): array|WP_Error {
		if ( ! $this->is_enabled() ) {
			return new WP_Error( 'seoauto_feature_denied', __( 'Thiếu feature: ai_seo_assistant.', 'seoauto-seo-helper' ), array( 'status' => 403 ) );
		}
		return $this->content_ops->rollback( array( 'batch_id' => $batch_id ) );
	}
}
