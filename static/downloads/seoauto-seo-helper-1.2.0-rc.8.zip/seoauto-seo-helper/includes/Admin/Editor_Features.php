<?php
/**
 * Admin-only editor assets + AJAX for Publish Guard and AI SEO Assistant.
 * Never enqueued on the public frontend.
 *
 * @package SEOAuto\SEOHelper
 */

declare(strict_types=1);

namespace SEOAuto\SEOHelper\Admin;

use SEOAuto\SEOHelper\AiSeo\Ai_Seo_Assistant_Service;
use SEOAuto\SEOHelper\PublishGuard\Publish_Guard_Service;
use WP_Error;

final class Editor_Features {

	public function __construct(
		private Publish_Guard_Service $publish_guard,
		private Ai_Seo_Assistant_Service $ai_seo
	) {}

	public function register(): void {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
		add_action( 'enqueue_block_editor_assets', array( $this, 'enqueue_block_editor' ) );
		add_action( 'add_meta_boxes', array( $this, 'classic_metabox' ) );

		add_action( 'wp_ajax_seoauto_helper_pg_check', array( $this, 'ajax_pg_check' ) );
		add_action( 'wp_ajax_seoauto_helper_pg_intent', array( $this, 'ajax_pg_intent' ) );
		add_action( 'wp_ajax_seoauto_helper_pg_intent_status', array( $this, 'ajax_pg_intent_status' ) );
		add_action( 'wp_ajax_seoauto_helper_pg_dismiss', array( $this, 'ajax_pg_dismiss' ) );
		add_action( 'wp_ajax_seoauto_helper_ai_suggest', array( $this, 'ajax_ai_suggest' ) );
		add_action( 'wp_ajax_seoauto_helper_ai_suggest_status', array( $this, 'ajax_ai_suggest_status' ) );
		add_action( 'wp_ajax_seoauto_helper_ai_apply', array( $this, 'ajax_ai_apply' ) );
		add_action( 'wp_ajax_seoauto_helper_ai_rollback', array( $this, 'ajax_ai_rollback' ) );
	}

	public function enqueue( string $hook ): void {
		if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			return;
		}
		if ( ! current_user_can( 'edit_posts' ) ) {
			return;
		}
		$pg = $this->publish_guard->is_enabled();
		$ai = $this->ai_seo->is_enabled();
		if ( ! $pg && ! $ai ) {
			return;
		}

		wp_enqueue_style(
			'seoauto-helper-editor',
			SEOAUTO_HELPER_URL . 'assets/admin/editor-features.css',
			array(),
			SEOAUTO_HELPER_VERSION
		);
		wp_enqueue_script(
			'seoauto-helper-editor',
			SEOAUTO_HELPER_URL . 'assets/admin/editor-features.js',
			array( 'jquery' ),
			SEOAUTO_HELPER_VERSION,
			true
		);
		wp_localize_script(
			'seoauto-helper-editor',
			'seoautoHelperEditor',
			array(
				'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
				'nonce'        => wp_create_nonce( 'seoauto_helper_editor' ),
				'publishGuard' => $pg,
				'aiAssistant'  => $ai,
				'i18n'         => array(
					'checking'   => __( 'Đang kiểm tra SEO…', 'seoauto-seo-helper' ),
					'dismiss'    => __( 'Bỏ qua và đăng', 'seoauto-seo-helper' ),
					'suggest'    => __( 'Gợi ý AI', 'seoauto-seo-helper' ),
					'apply'      => __( 'Preview → Apply', 'seoauto-seo-helper' ),
					'noBlock'    => __( 'Cảnh báo không chặn đăng bài.', 'seoauto-seo-helper' ),
				),
			)
		);
	}

	public function enqueue_block_editor(): void {
		// Same gate — assets only loaded in block editor admin context via enqueue above on post screens.
		// Additional block script can hook if present.
		if ( ! $this->publish_guard->is_enabled() && ! $this->ai_seo->is_enabled() ) {
			return;
		}
		$script = SEOAUTO_HELPER_PATH . 'assets/admin/gutenberg-panel.js';
		if ( ! is_readable( $script ) ) {
			return;
		}
		wp_enqueue_script(
			'seoauto-helper-gutenberg',
			SEOAUTO_HELPER_URL . 'assets/admin/gutenberg-panel.js',
			array( 'wp-plugins', 'wp-edit-post', 'wp-element', 'wp-components', 'wp-data', 'seoauto-helper-editor' ),
			SEOAUTO_HELPER_VERSION,
			true
		);
	}

	public function classic_metabox(): void {
		if ( ! $this->publish_guard->is_enabled() && ! $this->ai_seo->is_enabled() ) {
			return;
		}
		$types = array( 'post', 'page' );
		foreach ( $types as $type ) {
			add_meta_box(
				'seoauto-helper-editor-box',
				__( 'SEOAuto Publish Guard / AI', 'seoauto-seo-helper' ),
				array( $this, 'render_metabox' ),
				$type,
				'side',
				'high'
			);
		}
	}

	public function render_metabox( \WP_Post $post ): void {
		echo '<div id="seoauto-helper-classic-panel" data-post-id="' . esc_attr( (string) $post->ID ) . '">';
		echo '<p class="description">' . esc_html__( 'Kiểm tra nhanh trước khi đăng. Không khóa đăng mặc định.', 'seoauto-seo-helper' ) . '</p>';
		if ( $this->publish_guard->is_enabled() ) {
			echo '<p><button type="button" class="button seoauto-pg-run">' . esc_html__( 'Chạy Publish Guard', 'seoauto-seo-helper' ) . '</button></p>';
		}
		if ( $this->ai_seo->is_enabled() ) {
			echo '<p><button type="button" class="button seoauto-ai-run">' . esc_html__( 'Gợi ý AI SEO', 'seoauto-seo-helper' ) . '</button></p>';
		}
		echo '<div class="seoauto-editor-results"></div></div>';
	}

	public function ajax_pg_check(): void {
		$this->guard_ajax();
		if ( ! $this->publish_guard->is_enabled() ) {
			wp_send_json_error( array( 'code' => 'seoauto_feature_denied' ), 403 );
		}
		$draft  = $this->draft_from_request();
		$result = $this->publish_guard->quick_check( $draft );
		$this->send( $result );
	}

	public function ajax_pg_intent(): void {
		$this->guard_ajax();
		if ( ! $this->publish_guard->is_enabled() ) {
			wp_send_json_error( array( 'code' => 'seoauto_feature_denied' ), 403 );
		}
		$result = $this->publish_guard->enqueue_intent( $this->draft_from_request() );
		$this->send( $result );
	}

	public function ajax_pg_intent_status(): void {
		$this->guard_ajax();
		$job = sanitize_text_field( (string) ( $_POST['job_id'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$this->send( $this->publish_guard->intent_status( $job ) );
	}

	public function ajax_pg_dismiss(): void {
		$this->guard_ajax();
		$post_id = (int) ( $_POST['post_id'] ?? 0 ); // phpcs:ignore
		$codes   = isset( $_POST['codes'] ) && is_array( $_POST['codes'] ) ? wp_unslash( $_POST['codes'] ) : array(); // phpcs:ignore
		$note    = sanitize_text_field( (string) ( $_POST['note'] ?? '' ) ); // phpcs:ignore
		$this->send( $this->publish_guard->dismiss( $post_id, $codes, $note ) );
	}

	public function ajax_ai_suggest(): void {
		$this->guard_ajax();
		if ( ! $this->ai_seo->is_enabled() ) {
			wp_send_json_error( array( 'code' => 'seoauto_feature_denied' ), 403 );
		}
		$this->send( $this->ai_seo->suggest( $this->draft_from_request() ) );
	}

	public function ajax_ai_suggest_status(): void {
		$this->guard_ajax();
		$job = sanitize_text_field( (string) ( $_POST['job_id'] ?? '' ) ); // phpcs:ignore
		$this->send( $this->ai_seo->suggest_status( $job ) );
	}

	public function ajax_ai_apply(): void {
		$this->guard_ajax();
		if ( ! $this->ai_seo->is_enabled() ) {
			wp_send_json_error( array( 'code' => 'seoauto_feature_denied' ), 403 );
		}
		$post_id = (int) ( $_POST['post_id'] ?? 0 ); // phpcs:ignore
		$raw     = isset( $_POST['suggestions'] ) ? wp_unslash( $_POST['suggestions'] ) : '{}'; // phpcs:ignore
		if ( is_string( $raw ) ) {
			$suggestions = json_decode( $raw, true );
		} elseif ( is_array( $raw ) ) {
			$suggestions = $raw;
		} else {
			$suggestions = array();
		}
		if ( ! is_array( $suggestions ) ) {
			$suggestions = array();
		}
		$req = sanitize_text_field( (string) ( $_POST['request_id'] ?? '' ) ); // phpcs:ignore
		$this->send( $this->ai_seo->apply( $post_id, $suggestions, $req ) );
	}

	public function ajax_ai_rollback(): void {
		$this->guard_ajax();
		$batch = (int) ( $_POST['batch_id'] ?? 0 ); // phpcs:ignore
		$this->send( $this->ai_seo->rollback( $batch ) );
	}

	private function guard_ajax(): void {
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( array( 'code' => 'seoauto_forbidden' ), 403 );
		}
		check_ajax_referer( 'seoauto_helper_editor', 'nonce' );
	}

	/**
	 * @return array<string,mixed>
	 */
	private function draft_from_request(): array {
		$seo_raw = isset( $_POST['seo'] ) ? wp_unslash( $_POST['seo'] ) : array(); // phpcs:ignore
		$seo     = is_array( $seo_raw ) ? $seo_raw : ( is_string( $seo_raw ) ? ( json_decode( $seo_raw, true ) ?: array() ) : array() );
		return array(
			'post_id'     => (int) ( $_POST['post_id'] ?? 0 ), // phpcs:ignore
			'post_type'   => sanitize_key( (string) ( $_POST['post_type'] ?? 'post' ) ), // phpcs:ignore
			'post_status' => sanitize_key( (string) ( $_POST['post_status'] ?? 'draft' ) ), // phpcs:ignore
			'title'       => sanitize_text_field( (string) ( $_POST['title'] ?? '' ) ), // phpcs:ignore
			'content'     => (string) ( wp_unslash( $_POST['content'] ?? '' ) ), // phpcs:ignore
			'excerpt'     => sanitize_textarea_field( (string) ( $_POST['excerpt'] ?? '' ) ), // phpcs:ignore
			'seo'         => is_array( $seo ) ? $seo : array(),
			'focus_keyword'=> sanitize_text_field( (string) ( $_POST['focus_keyword'] ?? ( $seo['focus_keyword'] ?? '' ) ) ), // phpcs:ignore
			'permalink'   => esc_url_raw( (string) ( $_POST['permalink'] ?? '' ) ), // phpcs:ignore
		);
	}

	/**
	 * @param array<string,mixed>|WP_Error $result
	 */
	private function send( array|WP_Error $result ): void {
		if ( $result instanceof WP_Error ) {
			wp_send_json_error(
				array(
					'code'    => $result->get_error_code(),
					'message' => $result->get_error_message(),
					'data'    => $result->get_error_data(),
				),
				(int) ( is_array( $result->get_error_data() ) ? ( $result->get_error_data()['status'] ?? 400 ) : 400 )
			);
		}
		wp_send_json_success( $result );
	}
}
