<?php
/**
 * Publish Guard — local quick checks + async SaaS intent; never blocks publish by default.
 *
 * @package SEOAuto\SEOHelper
 */

declare(strict_types=1);

namespace SEOAuto\SEOHelper\PublishGuard;

use SEOAuto\SEOHelper\Audit\Audit_Logger;
use SEOAuto\SEOHelper\Connection\Connection_Manager;
use SEOAuto\SEOHelper\Entitlement\Entitlement_Manager;
use SEOAuto\SEOHelper\Seo\Seo_Facade;
use WP_Error;

final class Publish_Guard_Service {

	public const FEATURE           = 'publish_guard';
	public const META_DISMISSED    = '_seoauto_publish_guard_dismissed';
	public const META_INTENT_JOB   = '_seoauto_publish_guard_intent_job';

	private Local_Quick_Checker $local;
	private Intent_Client $intent;

	public function __construct(
		private Connection_Manager $connection,
		private Entitlement_Manager $entitlement,
		private Seo_Facade $seo,
		private Audit_Logger $audit,
		?Local_Quick_Checker $local = null,
		?Intent_Client $intent = null
	) {
		$this->local  = $local ?? new Local_Quick_Checker( $seo );
		$this->intent = $intent ?? new Intent_Client( $connection );
	}

	public function is_enabled(): bool {
		return $this->entitlement->has_feature( self::FEATURE )
			&& ! $this->entitlement->is_locked()
			&& $this->connection->has_credentials();
	}

	/**
	 * @param array<string,mixed> $draft
	 * @return array<string,mixed>|WP_Error
	 */
	public function quick_check( array $draft ): array|WP_Error {
		if ( ! $this->is_enabled() ) {
			return new WP_Error(
				'seoauto_feature_denied',
				__( 'Thiếu feature: publish_guard.', 'seoauto-seo-helper' ),
				array( 'status' => 403, 'code' => 'seoauto_feature_denied' )
			);
		}
		$result = $this->local->check( $draft );
		$this->audit->log(
			'publish_guard_local_check',
			array(
				'post_id'    => (int) ( $draft['post_id'] ?? 0 ),
				'issue_count'=> count( $result['issues'] ),
				'elapsed_ms' => $result['elapsed_ms'],
				'status'     => 'ok',
			)
		);
		return $result;
	}

	/**
	 * @param array<string,mixed> $draft
	 * @return array<string,mixed>|WP_Error
	 */
	public function enqueue_intent( array $draft ): array|WP_Error {
		if ( ! $this->is_enabled() ) {
			return new WP_Error( 'seoauto_feature_denied', __( 'Thiếu feature: publish_guard.', 'seoauto-seo-helper' ), array( 'status' => 403 ) );
		}
		$res = $this->intent->enqueue( $draft );
		if ( $res instanceof WP_Error ) {
			$this->audit->log_error( 'publish_guard_intent_enqueue', $res->get_error_code(), array( 'post_id' => (int) ( $draft['post_id'] ?? 0 ) ) );
			return $res;
		}
		$post_id = (int) ( $draft['post_id'] ?? 0 );
		if ( $post_id > 0 && ( $res['job_id'] ?? '' ) !== '' ) {
			update_post_meta( $post_id, self::META_INTENT_JOB, (string) $res['job_id'] );
		}
		$this->audit->log(
			'publish_guard_intent_enqueue',
			array(
				'post_id'    => $post_id,
				'job_id'     => (string) ( $res['job_id'] ?? '' ),
				'request_id' => (string) ( $res['request_id'] ?? '' ),
				'status'     => 'queued',
			)
		);
		return $res;
	}

	/**
	 * @return array<string,mixed>|WP_Error
	 */
	public function intent_status( string $job_id ): array|WP_Error {
		if ( ! $this->is_enabled() ) {
			return new WP_Error( 'seoauto_feature_denied', __( 'Thiếu feature: publish_guard.', 'seoauto-seo-helper' ), array( 'status' => 403 ) );
		}
		return $this->intent->status( $job_id );
	}

	/**
	 * User dismisses warnings and publishes anyway — always allowed; logged.
	 *
	 * @param list<string> $codes
	 * @return array{ok:bool}
	 */
	public function dismiss( int $post_id, array $codes, string $note = '' ): array|WP_Error {
		if ( ! $this->is_enabled() ) {
			return new WP_Error( 'seoauto_feature_denied', __( 'Thiếu feature: publish_guard.', 'seoauto-seo-helper' ), array( 'status' => 403 ) );
		}
		$codes = array_values( array_filter( array_map( 'sanitize_key', $codes ) ) );
		if ( $post_id > 0 ) {
			update_post_meta(
				$post_id,
				self::META_DISMISSED,
				array(
					'at'    => gmdate( 'c' ),
					'codes' => $codes,
					'note'  => sanitize_text_field( $note ),
					'user'  => get_current_user_id(),
				)
			);
		}
		$this->audit->log(
			'publish_guard_dismiss',
			array(
				'post_id' => $post_id,
				'codes'   => $codes,
				'note'    => sanitize_text_field( $note ),
				'status'  => 'ok',
			)
		);
		return array( 'ok' => true, 'blocking' => false );
	}
}
