<?php
/**
 * Private plugin updater — wires WordPress update UI via Update URI host filter.
 *
 * LOCKED sites still receive security patches (update check does not require
 * paid features). Does not modify Billing / Credit / HMAC crypto.
 *
 * @package SEOAuto\SEOHelper
 */

declare(strict_types=1);

namespace SEOAuto\SEOHelper\Updater;

use SEOAuto\SEOHelper\Audit\Audit_Logger;
use SEOAuto\SEOHelper\Connection\Connection_Manager;
use SEOAuto\SEOHelper\Entitlement\Entitlement_Manager;
use WP_Error;

final class Update_Manager {

	public const CACHE_OPTION   = 'update_check_cache';
	public const CACHE_TTL      = 6 * \HOUR_IN_SECONDS;
	public const CHANNEL_OPTION = 'update_channel';
	public const HOST_FILTER    = 'update_plugins_seoauto.vn';

	private Update_Client $client;
	private Package_Verifier $verifier;

	public function __construct(
		private Connection_Manager $connection,
		private Entitlement_Manager $entitlement,
		private Audit_Logger $audit,
		?Update_Client $client = null,
		?Package_Verifier $verifier = null
	) {
		$this->client   = $client ?? new Update_Client( $this->connection );
		$this->verifier = $verifier ?? new Package_Verifier();
	}

	public function register(): void {
		add_filter( self::HOST_FILTER, array( $this, 'filter_update' ), 10, 4 );
		// Primary path for native Plugins banner (“nâng cấp ngay”) — same as Wordfence.
		add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'inject_update_transient' ) );
		add_filter( 'site_transient_update_plugins', array( $this, 'inject_update_transient' ) );
		add_filter( 'plugins_api', array( $this, 'plugins_api' ), 10, 3 );
		add_filter( 'upgrader_pre_download', array( $this, 'pre_download' ), 10, 3 );
		add_filter( 'auto_update_plugin', array( $this, 'auto_update_plugin' ), 10, 2 );
		add_action( 'upgrader_process_complete', array( $this, 'after_upgrade' ), 10, 2 );
		// Must run before wp_plugin_update_rows() (admin_init default 10) so core hooks wp_plugin_update_row.
		add_action( 'admin_init', array( $this, 'bootstrap_plugins_update_row' ), 1 );
	}

	/**
	 * Ensure update cache + WP core update row hook before Plugins list renders.
	 */
	public function bootstrap_plugins_update_row(): void {
		if ( ! is_admin() || ! current_user_can( 'update_plugins' ) ) {
			return;
		}
		if ( ! $this->connection->has_credentials() ) {
			return;
		}

		$screen_ok = false;
		if ( function_exists( 'get_current_screen' ) ) {
			$screen = get_current_screen();
			if ( $screen && in_array( $screen->id, array( 'plugins', 'plugins-network', 'update-core' ), true ) ) {
				$screen_ok = true;
			}
		}
		global $pagenow;
		if ( isset( $pagenow ) && in_array( (string) $pagenow, array( 'plugins.php', 'update-core.php' ), true ) ) {
			$screen_ok = true;
		}
		if ( ! $screen_ok ) {
			// Still keep transient warm if we already know an update exists.
			$available = $this->available_update();
			if ( $available instanceof Update_Response ) {
				$this->refresh_wp_plugins_transient( $available );
				$this->ensure_core_update_row_hooked();
			}
			return;
		}

		$available = $this->available_update();
		if ( ! $available instanceof Update_Response ) {
			$cached = $this->read_cache();
			// Cache miss, or negative/stale result older than 15 minutes → re-check SaaS.
			$should_fetch = null === $cached;
			if ( ! $should_fetch && $cached instanceof Update_Response && ! $cached->update_available ) {
				$raw = $this->connection->option( self::CACHE_OPTION, '' );
				$data = is_string( $raw ) ? json_decode( $raw, true ) : null;
				$checked_at = is_array( $data ) ? (int) ( $data['checked_at'] ?? 0 ) : 0;
				$should_fetch = $checked_at <= 0 || ( time() - $checked_at ) > 15 * 60;
			}
			if ( $should_fetch ) {
				$result = $this->force_check();
				if ( $result instanceof Update_Response && $result->update_available ) {
					$available = $result;
				}
			}
		}

		if ( $available instanceof Update_Response ) {
			$this->refresh_wp_plugins_transient( $available );
			$this->ensure_core_update_row_hooked();
		}
	}

	/**
	 * Register WordPress core banner renderer (same UI as Wordfence).
	 */
	public function ensure_core_update_row_hooked(): void {
		$file = SEOAUTO_HELPER_BASENAME;
		if ( ! has_action( "after_plugin_row_{$file}", 'wp_plugin_update_row' ) ) {
			add_action( "after_plugin_row_{$file}", 'wp_plugin_update_row', 10, 2 );
		}
	}

	/**
	 * @param false|object|array $update
	 * @param array<string,mixed> $plugin_data
	 * @param string $plugin_file
	 * @param string[] $locales
	 * @return false|object
	 */
	public function filter_update( $update, $plugin_data, $plugin_file, $locales ) {
		if ( ! $this->is_our_plugin_file( (string) $plugin_file ) ) {
			return $update;
		}

		$obj = $this->build_wp_update_object( false );
		return $obj ? $obj : false;
	}

	/**
	 * Ensure Plugins / Dashboard Updates always see our private package when available.
	 * Cache-only — never HTTP here (avoid SaaS storms on every get_site_transient).
	 *
	 * @param mixed $transient
	 * @return mixed
	 */
	public function inject_update_transient( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}

		$basename = SEOAUTO_HELPER_BASENAME;
		if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
			$transient->response = array();
		}
		if ( ! isset( $transient->no_update ) || ! is_array( $transient->no_update ) ) {
			$transient->no_update = array();
		}
		if ( ! isset( $transient->checked ) || ! is_array( $transient->checked ) ) {
			$transient->checked = array();
		}
		$transient->checked[ $basename ] = SEOAUTO_HELPER_VERSION;

		$obj = $this->build_wp_update_object_from_cache();
		if ( ! $obj ) {
			unset( $transient->response[ $basename ] );
			// Required for auto-update UI + consistent Plugins list behavior.
			$transient->no_update[ $basename ] = $this->no_update_stub();
			return $transient;
		}

		$transient->response[ $basename ] = $obj;
		unset( $transient->no_update[ $basename ] );
		return $transient;
	}

	/**
	 * @return object
	 */
	private function no_update_stub() {
		return (object) array(
			'id'            => 'seoauto-seo-helper/' . SEOAUTO_HELPER_VERSION,
			'slug'          => 'seoauto-seo-helper',
			'plugin'        => SEOAUTO_HELPER_BASENAME,
			'new_version'   => SEOAUTO_HELPER_VERSION,
			'url'           => 'https://seoauto.vn',
			'package'       => '',
			'icons'         => array(),
			'banners'       => array(),
			'banners_rtl'   => array(),
			'tested'        => '6.7',
			'requires_php'  => '8.1',
			'compatibility' => new \stdClass(),
		);
	}

	/**
	 * Build WP update object from cache/SaaS when a newer package is available.
	 *
	 * @return object|false
	 */
	public function build_wp_update_object( bool $force_fetch = false ) {
		$response = $this->get_cached_or_fetch( $force_fetch );
		return $this->response_to_wp_object( $response );
	}

	/**
	 * @return object|false
	 */
	public function build_wp_update_object_from_cache() {
		return $this->response_to_wp_object( $this->read_cache() );
	}

	/**
	 * @param Update_Response|WP_Error|null $response
	 * @return object|false
	 */
	private function response_to_wp_object( $response ) {
		if ( ! $response instanceof Update_Response || ! $response->update_available ) {
			return false;
		}

		$newer = $this->verifier->assert_newer_version( SEOAUTO_HELPER_VERSION, $response->version );
		if ( $newer instanceof WP_Error ) {
			return false;
		}
		$url_ok = $this->verifier->assert_safe_package_url( $response->package );
		if ( $url_ok instanceof WP_Error ) {
			return false;
		}

		$obj = $response->to_wp_update_object();
		return $obj ? $obj : false;
	}

	public function is_our_plugin_file( string $plugin_file ): bool {
		$plugin_file = str_replace( '\\', '/', $plugin_file );
		if ( $plugin_file === SEOAUTO_HELPER_BASENAME ) {
			return true;
		}
		return str_ends_with( $plugin_file, '/seoauto-seo-helper.php' )
			|| $plugin_file === 'seoauto-seo-helper.php';
	}

	/**
	 * Plugin details modal ("View details").
	 *
	 * @param false|object|array $result
	 * @param string $action
	 * @param object $args
	 * @return false|object|array
	 */
	public function plugins_api( $result, $action, $args ) {
		if ( 'plugin_information' !== $action ) {
			return $result;
		}
		$slug = is_object( $args ) ? (string) ( $args->slug ?? '' ) : '';
		if ( $slug !== 'seoauto-seo-helper' ) {
			return $result;
		}

		$response = $this->get_cached_or_fetch( false );
		$version  = $response instanceof Update_Response && $response->version !== ''
			? $response->version
			: SEOAUTO_HELPER_VERSION;
		$changelog = $response instanceof Update_Response ? $response->changelog_url : 'https://seoauto.vn';

		return (object) array(
			'name'          => 'SEOAuto SEO Helper',
			'slug'          => 'seoauto-seo-helper',
			'version'       => $version,
			'author'        => '<a href="https://seoauto.vn">SEOAuto</a>',
			'homepage'      => 'https://seoauto.vn',
			'requires'      => $response instanceof Update_Response ? $response->requires_wp : '6.0',
			'requires_php'  => $response instanceof Update_Response ? $response->requires_php : '8.1',
			'tested'        => $response instanceof Update_Response ? $response->tested : '6.7',
			'sections'      => array(
				'description' => __( 'Kết nối WordPress với SEOAuto — SEO meta, publish, SEO Audit.', 'seoauto-seo-helper' ),
				'changelog'   => sprintf(
					'<p><a href="%s" target="_blank" rel="noopener noreferrer">%s</a></p>',
					esc_url( $changelog !== '' ? $changelog : 'https://seoauto.vn' ),
					esc_html__( 'Xem changelog trên SEOAuto', 'seoauto-seo-helper' )
				),
			),
			'download_link' => $response instanceof Update_Response ? $response->package : '',
		);
	}

	/**
	 * Download + verify package before WP extracts it.
	 *
	 * @param bool|string|\WP_Error $reply
	 * @param string $package
	 * @param \WP_Upgrader $upgrader
	 * @return bool|string|\WP_Error
	 */
	public function pre_download( $reply, $package, $upgrader ) {
		$package = (string) $package;
		if ( $package === '' || ! $this->is_our_package_url( $package ) ) {
			return $reply;
		}

		$url_ok = $this->verifier->assert_safe_package_url( $package );
		if ( $url_ok instanceof WP_Error ) {
			return $url_ok;
		}

		$cached = $this->read_cache();
		$meta   = $cached instanceof Update_Response ? $cached : null;

		$tmp = download_url( $package, 60 );
		if ( is_wp_error( $tmp ) ) {
			$this->audit->log_error(
				'plugin_update_download',
				'seoauto_update_download',
				array( 'status' => 'error' )
			);
			return $tmp;
		}

		// Integrity is mandatory for private packages — never install without meta.
		if ( ! $meta || $meta->sha256 === '' || $meta->version === '' ) {
			@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			$err = new WP_Error(
				'seoauto_update_meta_required',
				__( 'Thiếu metadata cập nhật (version/sha256). Chạy Kiểm tra cập nhật lại.', 'seoauto-seo-helper' )
			);
			$this->audit->log_error( 'plugin_update_meta', $err->get_error_code(), array( 'status' => 'error' ) );
			return $err;
		}

		$newer = $this->verifier->assert_newer_version( SEOAUTO_HELPER_VERSION, $meta->version );
		if ( $newer instanceof WP_Error ) {
			@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			$this->audit->log_error( 'plugin_update_downgrade', $newer->get_error_code(), array( 'status' => 'error' ) );
			return $newer;
		}

		$sha = $this->verifier->assert_sha256_file( $tmp, $meta->sha256 );
		if ( $sha instanceof WP_Error ) {
			@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			$this->audit->log_error( 'plugin_update_checksum', $sha->get_error_code(), array( 'status' => 'error' ) );
			return $sha;
		}

		if ( $meta->release_signature !== '' ) {
			$sig = $this->verifier->assert_release_signature(
				$meta->release_signature,
				$this->connection->site_secret(),
				$meta->version,
				$meta->sha256,
				$meta->download_expires_at
			);
			if ( $sig instanceof WP_Error ) {
				@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
				$this->audit->log_error( 'plugin_update_signature', $sig->get_error_code(), array( 'status' => 'error' ) );
				return $sig;
			}
		}

		$zip = $this->verifier->assert_zip_structure( $tmp );
		if ( $zip instanceof WP_Error ) {
			@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			$this->audit->log_error( 'plugin_update_zip', $zip->get_error_code(), array( 'status' => 'error' ) );
			return $zip;
		}

		$this->audit->log(
			'plugin_update_download_ok',
			array(
				'version' => $meta->version,
				'status'  => 'ok',
			)
		);

		return $tmp;
	}

	/**
	 * @param bool   $update
	 * @param object $item
	 */
	public function auto_update_plugin( $update, $item ): bool {
		$plugin = is_object( $item ) ? (string) ( $item->plugin ?? '' ) : '';
		if ( ! $this->is_our_plugin_file( $plugin ) ) {
			return (bool) $update;
		}
		$cached = $this->read_cache();
		if ( $cached instanceof Update_Response && $cached->autoupdate ) {
			return true;
		}
		return false;
	}

	/**
	 * @param \WP_Upgrader $upgrader
	 * @param array<string,mixed> $options
	 */
	public function after_upgrade( $upgrader, $options ): void {
		if ( ( $options['action'] ?? '' ) !== 'update' || ( $options['type'] ?? '' ) !== 'plugin' ) {
			return;
		}
		$plugins = $options['plugins'] ?? array();
		if ( ! is_array( $plugins ) || ! in_array( SEOAUTO_HELPER_BASENAME, $plugins, true ) ) {
			return;
		}
		$this->clear_cache();
		// Migration must also run on next boot via Schema::maybe_upgrade().
		if ( class_exists( '\\SEOAuto\\SEOHelper\\Post\\Schema' ) ) {
			\SEOAuto\SEOHelper\Post\Schema::maybe_upgrade();
		}
		$this->audit->log( 'plugin_update_complete', array( 'status' => 'ok', 'to' => SEOAUTO_HELPER_VERSION ) );
	}

	/**
	 * Force refresh (admin "Check for updates").
	 *
	 * @return Update_Response|WP_Error
	 */
	public function force_check() {
		$this->clear_cache();
		$result = $this->get_cached_or_fetch( true );
		if ( $result instanceof Update_Response ) {
			$this->refresh_wp_plugins_transient( $result );
			if ( $result->update_available ) {
				$this->ensure_core_update_row_hooked();
			}
		}
		return $result;
	}

	/**
	 * Push (or clear) our entry in WP's update_plugins transient immediately.
	 */
	public function refresh_wp_plugins_transient( Update_Response $response ): void {
		$transient = get_site_transient( 'update_plugins' );
		if ( ! is_object( $transient ) ) {
			$transient = (object) array(
				'last_checked' => time(),
				'response'     => array(),
				'no_update'    => array(),
				'checked'      => array(
					SEOAUTO_HELPER_BASENAME => SEOAUTO_HELPER_VERSION,
				),
			);
		}

		$basename = SEOAUTO_HELPER_BASENAME;
		$obj      = null;
		if ( $response->update_available ) {
			$newer = $this->verifier->assert_newer_version( SEOAUTO_HELPER_VERSION, $response->version );
			$url_ok = $this->verifier->assert_safe_package_url( $response->package );
			if ( ! ( $newer instanceof WP_Error ) && ! ( $url_ok instanceof WP_Error ) ) {
				$obj = $response->to_wp_update_object();
			}
		}

		if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
			$transient->response = array();
		}
		if ( ! isset( $transient->no_update ) || ! is_array( $transient->no_update ) ) {
			$transient->no_update = array();
		}
		if ( ! isset( $transient->checked ) || ! is_array( $transient->checked ) ) {
			$transient->checked = array();
		}
		$transient->checked[ $basename ] = SEOAUTO_HELPER_VERSION;
		$transient->last_checked           = time();

		if ( $obj ) {
			$transient->response[ $basename ] = $obj;
			unset( $transient->no_update[ $basename ] );
		} else {
			unset( $transient->response[ $basename ] );
		}

		// Avoid re-entrancy loops through site_transient_update_plugins while writing.
		remove_filter( 'site_transient_update_plugins', array( $this, 'inject_update_transient' ) );
		remove_filter( 'pre_set_site_transient_update_plugins', array( $this, 'inject_update_transient' ) );
		set_site_transient( 'update_plugins', $transient );
		add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'inject_update_transient' ) );
		add_filter( 'site_transient_update_plugins', array( $this, 'inject_update_transient' ) );
	}

	public function clear_cache(): void {
		delete_option( SEOAUTO_HELPER_PREFIX . self::CACHE_OPTION );
		// Do not delete the whole update_plugins transient (would wipe other plugins).
		$transient = get_site_transient( 'update_plugins' );
		if ( is_object( $transient ) && isset( $transient->response ) && is_array( $transient->response ) ) {
			unset( $transient->response[ SEOAUTO_HELPER_BASENAME ] );
			remove_filter( 'site_transient_update_plugins', array( $this, 'inject_update_transient' ) );
			remove_filter( 'pre_set_site_transient_update_plugins', array( $this, 'inject_update_transient' ) );
			set_site_transient( 'update_plugins', $transient );
			add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'inject_update_transient' ) );
			add_filter( 'site_transient_update_plugins', array( $this, 'inject_update_transient' ) );
		}
	}

	/**
	 * Offer currently cached update (if any) for admin UI / plugin row.
	 */
	public function available_update(): ?Update_Response {
		$cached = $this->read_cache();
		if ( ! $cached instanceof Update_Response || ! $cached->update_available ) {
			return null;
		}
		$newer = $this->verifier->assert_newer_version( SEOAUTO_HELPER_VERSION, $cached->version );
		if ( $newer instanceof WP_Error ) {
			return null;
		}
		if ( $cached->package === '' ) {
			return null;
		}
		return $cached;
	}

	public function channel(): string {
		return self::resolve_channel(
			(string) $this->connection->option( self::CHANNEL_OPTION, '' ),
			defined( 'SEOAUTO_HELPER_VERSION' ) ? (string) SEOAUTO_HELPER_VERSION : '0'
		);
	}

	/**
	 * Explicit option wins; otherwise pre-release builds check the beta channel
	 * so RC canaries can see newer RCs without a manual channel toggle.
	 */
	public static function resolve_channel( string $stored, string $plugin_version ): string {
		$ch = sanitize_key( $stored );
		if ( in_array( $ch, array( 'stable', 'beta' ), true ) ) {
			return $ch;
		}
		return self::is_prerelease_version( $plugin_version ) ? 'beta' : 'stable';
	}

	public static function is_prerelease_version( string $version ): bool {
		return (bool) preg_match( '/-(?:rc|beta|alpha)(?:\.|$)/i', $version );
	}

	/**
	 * @return Update_Response|WP_Error|null
	 */
	public function read_cache() {
		$raw = $this->connection->option( self::CACHE_OPTION, '' );
		if ( ! is_string( $raw ) || $raw === '' ) {
			return null;
		}
		$data = json_decode( $raw, true );
		if ( ! is_array( $data ) ) {
			return null;
		}
		$checked = (int) ( $data['checked_at'] ?? 0 );
		if ( $checked > 0 && ( time() - $checked ) > self::CACHE_TTL ) {
			return null;
		}
		$payload = is_array( $data['response'] ?? null ) ? $data['response'] : array();
		$resp    = Update_Response::from_array( $payload );
		// Short-lived package URL: force re-check when expired (keep 6h metadata only while URL valid).
		if ( $resp->download_expires_at !== '' ) {
			$ts = strtotime( $resp->download_expires_at );
			if ( false !== $ts && time() > $ts ) {
				return null;
			}
		}
		return $resp;
	}

	/**
	 * @return Update_Response|WP_Error
	 */
	private function get_cached_or_fetch( bool $force ) {
		if ( ! $force ) {
			$cached = $this->read_cache();
			if ( $cached instanceof Update_Response ) {
				return $cached;
			}
		}

		// LOCKED still allowed — security patches independent of paid features.
		$channel = $this->channel();
		$result  = $this->client->check( $channel );
		if ( $result instanceof WP_Error ) {
			$this->audit->log_error(
				'plugin_update_check',
				$result->get_error_code(),
				array( 'status' => 'error', 'locked' => $this->entitlement->is_locked() )
			);
			return $result;
		}

		// Stable installs may still need a newer beta/RC while 1.2.0 stable is not published.
		if ( ! $result->update_available && $channel === 'stable' ) {
			$beta = $this->client->check( 'beta' );
			if ( $beta instanceof Update_Response && $beta->update_available ) {
				$result = $beta;
			}
		}

		$store = $result->to_array();
		$this->connection->update_option(
			self::CACHE_OPTION,
			wp_json_encode(
				array(
					'checked_at' => time(),
					'response'   => $store,
				)
			)
		);

		$this->audit->log(
			'plugin_update_check',
			array(
				'status'           => 'ok',
				'update_available' => $result->update_available,
				'version'          => $result->version,
				'channel'          => $result->channel,
				'locked'           => $this->entitlement->is_locked(),
			)
		);

		return $result;
	}

	private function is_our_package_url( string $url ): bool {
		$host = strtolower( (string) ( wp_parse_url( $url, PHP_URL_HOST ) ?? '' ) );
		$path = (string) ( wp_parse_url( $url, PHP_URL_PATH ) ?? '' );
		if ( $host === '' ) {
			return false;
		}
		$allowed = apply_filters( 'seoauto_helper_update_allowed_hosts', array( 'seoauto.vn', 'www.seoauto.vn', 'cdn.seoauto.vn', 'downloads.seoauto.vn' ) );
		if ( ! is_array( $allowed ) || ! in_array( $host, array_map( 'strtolower', $allowed ), true ) ) {
			return false;
		}
		return str_contains( $path, '/wordpress-plugin/updates/' ) || str_contains( $path, 'seoauto-seo-helper' );
	}
}
