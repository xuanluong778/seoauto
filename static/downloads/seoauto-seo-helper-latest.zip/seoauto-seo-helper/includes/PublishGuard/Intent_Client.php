<?php
/**
 * Async duplicate / shared-intent checks via SEOAuto SaaS workers.
 * Plugin only collects draft data, enqueues job, and polls — no local intent analysis.
 *
 * SaaS paths:
 * - POST /api/wordpress-plugin/publish-guard/intent-checks
 * - GET  /api/wordpress-plugin/publish-guard/intent-checks/{job_id}
 *
 * @package SEOAuto\SEOHelper
 */

declare(strict_types=1);

namespace SEOAuto\SEOHelper\PublishGuard;

use SEOAuto\SEOHelper\Connection\Connection_Manager;
use SEOAuto\SEOHelper\Connection\SaaS_Request;
use WP_Error;

final class Intent_Client {

	public const ENQUEUE_PATH = '/api/wordpress-plugin/publish-guard/intent-checks';

	public function __construct(
		private Connection_Manager $connection,
		private ?SaaS_Request $http = null
	) {
		$this->http = $http ?? new SaaS_Request( $connection );
	}

	/**
	 * @param array<string,mixed> $payload
	 * @return array<string,mixed>|WP_Error
	 */
	public function enqueue( array $payload ): array|WP_Error {
		$request_id = sanitize_text_field( (string) ( $payload['request_id'] ?? wp_generate_uuid4() ) );
		$body       = wp_json_encode(
			array(
				'request_id'        => $request_id,
				'post_id'           => (int) ( $payload['post_id'] ?? 0 ),
				'title'             => (string) ( $payload['title'] ?? '' ),
				'content_excerpt'   => mb_substr( wp_strip_all_tags( (string) ( $payload['content'] ?? '' ) ), 0, 2000 ),
				'focus_keyword'     => (string) ( $payload['focus_keyword'] ?? '' ),
				'permalink'         => (string) ( $payload['permalink'] ?? '' ),
				'locale'            => get_locale(),
				'site_url'          => home_url( '/' ),
			)
		);
		if ( ! is_string( $body ) ) {
			return new WP_Error( 'seoauto_json', __( 'Không encode được payload intent.', 'seoauto-seo-helper' ) );
		}
		$res = $this->http->request( 'POST', self::ENQUEUE_PATH, $body, array(), 12 );
		if ( $res instanceof WP_Error ) {
			return $res;
		}
		$data = $res['body'];
		return array(
			'request_id' => $request_id,
			'job_id'     => (string) ( $data['job_id'] ?? $data['id'] ?? '' ),
			'status'     => (string) ( $data['status'] ?? 'queued' ),
			'async'      => true,
		);
	}

	/**
	 * @return array<string,mixed>|WP_Error
	 */
	public function status( string $job_id ): array|WP_Error {
		$job_id = sanitize_text_field( $job_id );
		if ( $job_id === '' ) {
			return new WP_Error( 'seoauto_missing_job', __( 'Thiếu job_id.', 'seoauto-seo-helper' ), array( 'status' => 400 ) );
		}
		$path = self::ENQUEUE_PATH . '/' . rawurlencode( $job_id );
		$res  = $this->http->request( 'GET', $path, '', array(), 12 );
		if ( $res instanceof WP_Error ) {
			return $res;
		}
		$data = $res['body'];
		return array(
			'job_id'   => $job_id,
			'status'   => (string) ( $data['status'] ?? 'unknown' ),
			'result'   => is_array( $data['result'] ?? null ) ? $data['result'] : $data,
			'blocking' => false,
		);
	}
}
