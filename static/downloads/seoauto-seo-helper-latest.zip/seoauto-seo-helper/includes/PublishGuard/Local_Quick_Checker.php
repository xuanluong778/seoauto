<?php
/**
 * Local Publish Guard checks — light on-page only (reuse SeoAudit checkers).
 * No network, no Broken_Link/Sitemap, no intent/KB/AI. Deep intent → SaaS Intent_Client.
 *
 * @package SEOAuto\SEOHelper
 */

declare(strict_types=1);

namespace SEOAuto\SEOHelper\PublishGuard;

use SEOAuto\SEOHelper\Seo\Seo_Facade;
use SEOAuto\SEOHelper\SeoAudit\Audit_Issue;
use SEOAuto\SEOHelper\SeoAudit\Checkers\Featured_Image_Checker;
use SEOAuto\SEOHelper\SeoAudit\Checkers\Heading_Checker;
use SEOAuto\SEOHelper\SeoAudit\Checkers\Image_Alt_Checker;
use SEOAuto\SEOHelper\SeoAudit\Checkers\Internal_Link_Checker;
use SEOAuto\SEOHelper\SeoAudit\Checkers\Meta_Description_Checker;
use SEOAuto\SEOHelper\SeoAudit\Checkers\Thin_Content_Checker;
use SEOAuto\SEOHelper\SeoAudit\Checkers\Title_Checker;
use SEOAuto\SEOHelper\SeoAudit\Checker_Interface;
use SEOAuto\SEOHelper\SeoAudit\Content_Text_Extractor;
use SEOAuto\SEOHelper\SeoAudit\Object_Context;
use SEOAuto\SEOHelper\SeoAudit\Seo_Meta_Reader;

final class Local_Quick_Checker {

	/** Hard budget for local checks (ms). */
	public const BUDGET_MS = 500;

	/** @var list<Checker_Interface> */
	private array $checkers;

	public function __construct( private Seo_Facade $seo ) {
		// Light on-page only: title, meta, H1/heading, length, internal link, alt, featured.
		// No Broken_Link / Sitemap (network). No Canonical/Schema/Robots (full audit / SaaS).
		$this->checkers = array(
			new Title_Checker(),
			new Meta_Description_Checker(),
			new Heading_Checker(),
			new Thin_Content_Checker(),
			new Image_Alt_Checker(),
			new Featured_Image_Checker(),
			new Internal_Link_Checker(),
		);
	}

	/**
	 * @param array{
	 *   post_id?:int,
	 *   post_type?:string,
	 *   post_status?:string,
	 *   title?:string,
	 *   content?:string,
	 *   excerpt?:string,
	 *   seo?:array<string,mixed>
	 * } $draft
	 * @return array{elapsed_ms:float,issues:list<array<string,mixed>>,within_budget:bool}
	 */
	public function check( array $draft ): array {
		$t0  = microtime( true );
		$ctx = $this->context_from_draft( $draft );
		$out = array();
		foreach ( $this->checkers as $checker ) {
			try {
				foreach ( $checker->check( $ctx ) as $issue ) {
					if ( $issue instanceof Audit_Issue ) {
						$out[] = $this->present_issue( $issue );
					}
				}
			} catch ( \Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement
				// Isolate checker failures — never block the editor.
			}
			$elapsed = ( microtime( true ) - $t0 ) * 1000;
			if ( $elapsed > self::BUDGET_MS ) {
				break;
			}
		}
		$elapsed = ( microtime( true ) - $t0 ) * 1000;
		return array(
			'elapsed_ms'     => round( $elapsed, 2 ),
			'issues'         => $out,
			'within_budget'  => $elapsed <= self::BUDGET_MS,
			'budget_ms'      => self::BUDGET_MS,
			'content_sources'=> $ctx->content_sources,
		);
	}

	/**
	 * @param array<string,mixed> $draft
	 */
	private function context_from_draft( array $draft ): Object_Context {
		$id      = (int) ( $draft['post_id'] ?? 0 );
		$title   = (string) ( $draft['title'] ?? '' );
		$content = (string) ( $draft['content'] ?? '' );
		$type    = sanitize_key( (string) ( $draft['post_type'] ?? 'post' ) );
		$status  = sanitize_key( (string) ( $draft['post_status'] ?? 'draft' ) );

		$post = (object) array(
			'ID'           => $id,
			'post_title'   => $title,
			'post_content' => $content,
			'post_excerpt' => (string) ( $draft['excerpt'] ?? '' ),
			'post_type'    => $type !== '' ? $type : 'post',
			'post_status'  => $status !== '' ? $status : 'draft',
		);

		$extracted = Content_Text_Extractor::extract( $post );
		$reader    = new Seo_Meta_Reader( $this->seo );
		$seo       = $id > 0 ? $reader->read( $id ) : array(
			'adapter'             => $this->seo->active_id(),
			'description_source'  => 'none',
			'title'               => '',
			'description'         => '',
			'focus_keyword'       => '',
			'canonical'           => '',
			'robots_index'        => null,
			'robots_follow'       => null,
			'schema_type'         => '',
		);

		// Overlay editor SEO fields (unsaved).
		$overlay = is_array( $draft['seo'] ?? null ) ? $draft['seo'] : array();
		foreach ( array( 'title', 'description', 'focus_keyword', 'canonical', 'schema_type' ) as $k ) {
			if ( isset( $overlay[ $k ] ) && is_scalar( $overlay[ $k ] ) && (string) $overlay[ $k ] !== '' ) {
				$seo[ $k ] = (string) $overlay[ $k ];
			}
		}
		if ( array_key_exists( 'robots_index', $overlay ) ) {
			$seo['robots_index'] = is_bool( $overlay['robots_index'] ) ? $overlay['robots_index'] : null;
		}

		$permalink = $id > 0 ? (string) get_permalink( $id ) : home_url( '/' );
		$featured  = $id > 0 ? has_post_thumbnail( $id ) : ! empty( $draft['has_featured_image'] );

		return new Object_Context(
			$id,
			(string) $post->post_type,
			(string) $post->post_status,
			$title !== '' ? $title : (string) ( $seo['title'] ?? '' ),
			(string) $extracted['html'],
			(string) $extracted['text'],
			(int) $extracted['word_count'],
			$permalink,
			(bool) $featured,
			$seo,
			$extracted['images'],
			$extracted['links'],
			$extracted['headings'],
			(string) ( $seo['adapter'] ?? 'native' ),
			$extracted['sources']
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	private function present_issue( Audit_Issue $issue ): array {
		return array(
			'code'            => $issue->issue_code,
			'severity'        => $issue->severity,
			'risk_level'      => $issue->risk_level,
			'message'         => $issue->message,
			'current_value'   => $issue->current_value,
			'suggested_value' => $issue->suggested_value,
			'blocking'        => false, // Never block publish by default.
		);
	}
}
