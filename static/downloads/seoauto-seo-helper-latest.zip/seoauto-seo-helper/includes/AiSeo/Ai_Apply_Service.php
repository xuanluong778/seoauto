<?php
/**
 * Apply AI SEO suggestions through existing ContentOps pipeline only.
 * SEO meta writes happen inside ContentOps → Restore_Service → Seo_Facade.
 * No Elementor/Beaver/Divi content writes. No LLM in the plugin.
 *
 * @package SEOAuto\SEOHelper
 */

declare(strict_types=1);

namespace SEOAuto\SEOHelper\AiSeo;

use SEOAuto\SEOHelper\Audit\Audit_Logger;
use SEOAuto\SEOHelper\ContentOps\ContentOps_Service;
use WP_Error;

final class Ai_Apply_Service {

	public function __construct(
		private ContentOps_Service $content_ops,
		private Audit_Logger $audit
	) {}

	/**
	 * Build ContentOps proposed payload from AI suggestions (SEO-safe fields only).
	 *
	 * @param array<string,mixed> $suggestions
	 * @return array<string,mixed>|WP_Error
	 */
	public function build_proposed( int $post_id, array $suggestions ): array|WP_Error {
		if ( $post_id <= 0 || ! get_post( $post_id ) ) {
			return new WP_Error( 'seoauto_missing_post', __( 'Bài viết không tồn tại.', 'seoauto-seo-helper' ), array( 'status' => 404 ) );
		}

		// Refuse content body writes when page builders own the document.
		if ( $this->has_unsafe_builder( $post_id ) && $this->wants_content_write( $suggestions ) ) {
			return new WP_Error(
				'seoauto_builder_write_blocked',
				__( 'Không ghi nội dung vào Elementor/Beaver/Divi khi chưa có write adapter an toàn. Chỉ áp dụng SEO meta.', 'seoauto-seo-helper' ),
				array( 'status' => 409 )
			);
		}

		$seo = array();
		if ( ! empty( $suggestions['title'] ) && is_string( $suggestions['title'] ) ) {
			$seo['title'] = sanitize_text_field( $suggestions['title'] );
		}
		if ( ! empty( $suggestions['meta_description'] ) && is_string( $suggestions['meta_description'] ) ) {
			$seo['description'] = sanitize_textarea_field( $suggestions['meta_description'] );
		}
		if ( ! empty( $suggestions['focus_keyword'] ) && is_string( $suggestions['focus_keyword'] ) ) {
			$seo['focus_keyword'] = sanitize_text_field( $suggestions['focus_keyword'] );
		}
		if ( ! empty( $suggestions['canonical'] ) && is_string( $suggestions['canonical'] ) ) {
			$seo['canonical'] = esc_url_raw( $suggestions['canonical'] );
		}

		$proposed = array();
		if ( $seo !== array() ) {
			$proposed['seo'] = $seo;
		}
		// Outline / FAQ / CTA / heading suggestions are preview-only unless mapped to safe excerpt.
		if ( ! empty( $suggestions['excerpt'] ) && is_string( $suggestions['excerpt'] ) ) {
			$proposed['excerpt'] = sanitize_textarea_field( $suggestions['excerpt'] );
		}

		if ( $proposed === array() ) {
			return new WP_Error( 'seoauto_empty_proposal', __( 'Không có trường SEO an toàn để Apply.', 'seoauto-seo-helper' ), array( 'status' => 400 ) );
		}

		return $proposed;
	}

	/**
	 * Preview → Backup → Apply via ContentOps (idempotent request_id).
	 *
	 * @param array<string,mixed> $suggestions
	 * @return array<string,mixed>|WP_Error
	 */
	public function apply_via_content_ops( int $post_id, array $suggestions, string $request_id = '' ): array|WP_Error {
		$proposed = $this->build_proposed( $post_id, $suggestions );
		if ( $proposed instanceof WP_Error ) {
			return $proposed;
		}

		$request_id = $request_id !== '' ? $request_id : ( 'ai-apply-' . wp_generate_uuid4() );
		$item       = array(
			'post_id'         => $post_id,
			'proposed'        => $proposed,
			'reason'          => 'ai_seo_assistant',
			'idempotency_key' => 'ai_' . $post_id . '_' . md5( wp_json_encode( $proposed ) ?: '' ),
		);

		$preview = $this->content_ops->preview(
			array(
				'request_id' => $request_id . '-preview',
				'items'      => array( $item ),
			)
		);
		if ( $preview instanceof WP_Error ) {
			return $preview;
		}

		$backup = $this->content_ops->backup(
			array(
				'request_id' => $request_id,
				'items'      => array( $item ),
			)
		);
		if ( $backup instanceof WP_Error ) {
			return $backup;
		}
		if ( ! empty( $backup['apply_blocked'] ) ) {
			return new WP_Error( 'seoauto_apply_blocked_backup', __( 'Backup thất bại — Apply bị chặn.', 'seoauto-seo-helper' ), array( 'status' => 409 ) );
		}

		$apply = $this->content_ops->apply(
			array(
				'batch_id'   => (int) ( $backup['batch_id'] ?? 0 ),
				'request_id' => $request_id,
			)
		);
		if ( $apply instanceof WP_Error ) {
			return $apply;
		}

		// SEO meta is applied solely by ContentOps (Restore_Service → Seo_Facade). Do not re-write here.

		$recheck = $this->content_ops->recheck(
			array(
				'batch_id' => (int) ( $backup['batch_id'] ?? 0 ),
			)
		);

		$this->audit->log(
			'ai_seo_apply',
			array(
				'post_id'    => $post_id,
				'request_id' => $request_id,
				'batch_id'   => (int) ( $backup['batch_id'] ?? 0 ),
				'status'     => 'ok',
				'fields'     => array_keys( $proposed ),
			)
		);

		return array(
			'request_id' => $request_id,
			'batch_id'   => (int) ( $backup['batch_id'] ?? 0 ),
			'preview'    => $preview,
			'backup'     => $backup,
			'apply'      => $apply,
			'recheck'    => $recheck instanceof WP_Error ? array( 'error' => $recheck->get_error_code() ) : $recheck,
		);
	}

	private function has_unsafe_builder( int $post_id ): bool {
		$el = get_post_meta( $post_id, '_elementor_data', true );
		if ( is_string( $el ) && $el !== '' && $el !== '[]' ) {
			return true;
		}
		if ( get_post_meta( $post_id, '_fl_builder_data', true ) ) {
			return true;
		}
		if ( get_post_meta( $post_id, '_et_pb_use_builder', true ) === 'on' ) {
			return true;
		}
		return false;
	}

	/**
	 * @param array<string,mixed> $suggestions
	 */
	private function wants_content_write( array $suggestions ): bool {
		foreach ( array( 'content', 'post_content', 'body_html', 'outline_html' ) as $k ) {
			if ( ! empty( $suggestions[ $k ] ) ) {
				return true;
			}
		}
		return false;
	}
}
