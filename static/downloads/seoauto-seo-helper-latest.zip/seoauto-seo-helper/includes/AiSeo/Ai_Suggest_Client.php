<?php
/**
 * Async AI SEO suggestions — enqueue + poll only. LLM/KB/RAG live on SEOAuto SaaS.
 *
 * SaaS paths:
 * - POST /api/wordpress-plugin/ai-seo/suggestions
 * - GET  /api/wordpress-plugin/ai-seo/suggestions/{job_id}
 *
 * @package SEOAuto\SEOHelper
 */

declare(strict_types=1);

namespace SEOAuto\SEOHelper\AiSeo;

use SEOAuto\SEOHelper\Connection\Connection_Manager;
use SEOAuto\SEOHelper\Connection\SaaS_Request;
use WP_Error;

final class Ai_Suggest_Client {

	public const ENQUEUE_PATH = '/api/wordpress-plugin/ai-seo/suggestions';

	public function __construct(
		private Connection_Manager $connection,
		private ?SaaS_Request $http = null
	) {
		$this->http = $http ?? new SaaS_Request( $connection );
	}

	/**
	 * @param array<string,mixed> $payload
	 * @return array<string,mixed>|WP_Error
	 */
	public function enqueue( array $payload ): array|WP_Error {
		$request_id = sanitize_text_field( (string) ( $payload['request_id'] ?? wp_generate_uuid4() ) );
		$kinds      = isset( $payload['kinds'] ) && is_array( $payload['kinds'] )
			? array_values( array_map( 'sanitize_key', $payload['kinds'] ) )
			: array( 'title', 'meta', 'outline', 'faq', 'cta', 'internal_links' );

		// Collect draft fields only. Tenant/org/KB binding comes from HMAC connection on SaaS.
		$body = wp_json_encode(
			array(
				'request_id'    => $request_id,
				'post_id'       => (int) ( $payload['post_id'] ?? 0 ),
				'title'         => (string) ( $payload['title'] ?? '' ),
				'content'       => mb_substr( (string) ( $payload['content'] ?? '' ), 0, 12000 ),
				'focus_keyword' => (string) ( $payload['focus_keyword'] ?? '' ),
				'kinds'         => $kinds,
				'locale'        => get_locale(),
				'site_url'      => home_url( '/' ),
			)
		);
		if ( ! is_string( $body ) ) {
			return new WP_Error( 'seoauto_json', __( 'Không encode được payload AI.', 'seoauto-seo-helper' ) );
		}
		$res = $this->http->request( 'POST', self::ENQUEUE_PATH, $body, array(), 15 );
		if ( $res instanceof WP_Error ) {
			return $res;
		}
		$data = $res['body'];
		return array(
			'request_id' => $request_id,
			'job_id'     => (string) ( $data['job_id'] ?? $data['id'] ?? '' ),
			'status'     => (string) ( $data['status'] ?? 'queued' ),
			'async'      => true,
		);
	}

	/**
	 * @return array<string,mixed>|WP_Error
	 */
	public function status( string $job_id ): array|WP_Error {
		$job_id = sanitize_text_field( $job_id );
		if ( $job_id === '' ) {
			return new WP_Error( 'seoauto_missing_job', __( 'Thiếu job_id.', 'seoauto-seo-helper' ), array( 'status' => 400 ) );
		}
		$path = self::ENQUEUE_PATH . '/' . rawurlencode( $job_id );
		$res  = $this->http->request( 'GET', $path, '', array(), 15 );
		if ( $res instanceof WP_Error ) {
			return $res;
		}
		$data = $res['body'];
		return array(
			'job_id' => $job_id,
			'status' => (string) ( $data['status'] ?? 'unknown' ),
			'suggestions' => is_array( $data['suggestions'] ?? null ) ? $data['suggestions'] : ( $data['result'] ?? array() ),
		);
	}
}
